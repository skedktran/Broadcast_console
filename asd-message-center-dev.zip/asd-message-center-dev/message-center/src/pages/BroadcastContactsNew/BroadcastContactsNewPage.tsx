import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useHistory, useParams } from 'react-router-dom'

import { FilterBar, Button } from '@skedulo/sked-ui'

import { RecipientType, State } from '../../Store'
import { getContacts } from '../../Store/reducerContacts'
import { broadcastContacts } from '../../Store/reducerBroadcasts'
import { useFilters } from '../../Store/filters/useFilters'
import { setContactsSelection } from '../../Store/reducerNewPage'

import { BackBar } from '../../components/BackBar'
import { ContactsMessengerHeader } from '../../components/MessengerHeader/MessengerHeader'
import MessageInput from '../../components/MessageInput'
import { RecipientsListBox } from '../../components/RecipientsListBox/RecipientsListBox'


import {
  broadcastContactsPath,
  broadcastContactsSummaryPath,
  broadcastContactsNewPath
} from '../routes'

import './BroadcastContactsNewPage.scss'

export const BroadcastContactsNewPage: React.FC = () => {
  const dispatch = useDispatch()
  const { preselectedContactIds } = useParams()
  const { filterOptions, onChange, filterString } = useFilters('Contacts')

  useEffect(() => {
    if (preselectedContactIds) {
      let ids: string[] = []
      try {
        ids = JSON.parse(preselectedContactIds)
      } catch (e) {
        ids = []
      }

      dispatch(setContactsSelection(ids))
      history.push(broadcastContactsNewPath())
    }
    return () => dispatch(setContactsSelection([]))
  }, [])

  useEffect(() => {
    dispatch(getContacts({ filter: filterString }))
  }, [filterString])

  const selectedContacts = useSelector(({ selectedContacts }: State) => selectedContacts)
  const [newMessage, setNewMessage] = useState('')
  const [loader, setLoader] = useState(false)

  const history = useHistory()

  const redirectToRoute = (route: (UID: string) => string) => (UID: string) => {
    history.push(route(UID))
  }

  const sendBroadcast = () => {
    setLoader(true)
    dispatch(broadcastContacts({
      message: newMessage,
      contactIds: selectedContacts
    }, redirectToRoute(broadcastContactsSummaryPath)))
  }

  return (
    <div className="message-contact">
      <div className="message-contact__filters">
        <BackBar route={ broadcastContactsPath() } />
        { filterOptions && <FilterBar filters={ filterOptions } onFilter={ onChange } /> }
      </div>
      <RecipientsListBox
        type={ RecipientType.Contact }
        className="message-contact__contact-list"
        searchClassName="message-contact__search"
        headerTitle="contact"
        footer
        selectable
        search
      />
      <div className="messenger">
        <ContactsMessengerHeader />
        <div className="messenger__messages">
          <div className="messenger__new-message">
            <MessageInput
              value={ newMessage }
              maxLength={ 500 }
              onChange={ setNewMessage }
              placeholder="Type here"
            />
            <div className="messenger__buttons-wrapper">
              <Button
                buttonType="primary"
                disabled={ !newMessage.length || !selectedContacts.length }
                onClick={ sendBroadcast }
                loading={ loader }
              >
                Send SMS
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
