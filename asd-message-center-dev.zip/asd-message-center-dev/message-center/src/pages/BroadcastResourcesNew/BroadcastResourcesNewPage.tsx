import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useHistory, useParams } from 'react-router-dom'

import { FilterBar, Button } from '@skedulo/sked-ui'

import { State, RecipientType, NotificationMethod } from '../../Store'
import { getResources } from '../../Store/reducerResources'
import { broadcastResources } from '../../Store/reducerBroadcasts'
import { useFilters } from '../../Store/filters/useFilters'
import { setResourcesSelection } from '../../Store/reducerNewPage'

import { BackBar } from '../../components/BackBar'
import MessengerHeader from '../../components/MessengerHeader'
import MessageInput from '../../components/MessageInput'
import { RecipientsListBox } from '../../components/RecipientsListBox/RecipientsListBox'

import {
  broadcastResourcesPath,
  broadcastResourcesSummaryPath,
  broadcastResourcesNewPath
} from '../routes'

import './BroadcastResourcesNewPage.scss'

export const BroadcastResourcesNewPage: React.FC = () => {
  const dispatch = useDispatch()
  const { preselectedResourceIds } = useParams()
  const { filterOptions, onChange, filterString } = useFilters('Resources')

  useEffect(() => {
    if (preselectedResourceIds) {
      let ids: string[] = []
      try {
        ids = JSON.parse(preselectedResourceIds)
      } catch (e) {
        ids = []
      }

      dispatch(setResourcesSelection(ids))
      history.push(broadcastResourcesNewPath())
    }
    return () => dispatch(setResourcesSelection([]))
  }, [])

  useEffect(() => {
    dispatch(getResources({ filter: filterString }))
  }, [filterString])

  const selectedResources = useSelector(({ selectedResources }: State) => selectedResources)
  const selectedResourcesInfor = useSelector(({ resources }: State) => resources.filter(res => selectedResources.includes(res.UID)))
  const [newMessage, setNewMessage] = useState('')
  const [loader, setLoader] = useState(undefined)

  const history = useHistory()

  const redirectToRoute = (route: (UID: string) => string) => (UID: string) => {
    history.push(route(UID))
  }

  const sendBroadcast = (method: NotificationMethod) => () => {
    setLoader(method)
    dispatch(broadcastResources({
      message: newMessage,
      resourceIds: selectedResources,
      notificationMethod: method
    }, redirectToRoute(broadcastResourcesSummaryPath)))
  }

  return (
    <div className="message-resource">
      <div className="message-resource__filters">
        <BackBar route={ broadcastResourcesPath() } />
        { filterOptions && <FilterBar filters={ filterOptions } onFilter={ onChange } /> }
      </div>
      <RecipientsListBox
        type={ RecipientType.Resource }
        className="message-resource__contact-list"
        searchClassName="message-resource__search"
        headerTitle="resource"
        footer
        selectable
        search
      />
      <div className="messenger">
        <MessengerHeader />
        <div className="messenger__messages">
          <div className="messenger__new-message">
            <MessageInput
              value={ newMessage }
              maxLength={ 500 }
              onChange={ setNewMessage }
              placeholder="Type here"
            />
            <div className="messenger__buttons-wrapper">
              <div className="messenger__send-methods">
                <Button
                  buttonType="secondary"
                  disabled={ (!newMessage.length || !selectedResources.length) || (loader && loader !== NotificationMethod.SMS) || selectedResourcesInfor.every(res => !res.MobilePhone) }
                  onClick={ sendBroadcast(NotificationMethod.SMS) }
                  loading={ loader === NotificationMethod.SMS }
                >
                  Send SMS
                </Button>
                <Button
                  disabled={ (!newMessage.length || !selectedResources.length) || (loader && loader !== NotificationMethod.Push) }
                  buttonType="secondary"
                  onClick={ sendBroadcast(NotificationMethod.Push) }
                  loading={ loader === NotificationMethod.Push }
                >
                  Send in app
                </Button>
              </div>
              <Button
                disabled={ (!newMessage.length || !selectedResources.length) || (loader && loader !== NotificationMethod.Preferred) }
                buttonType="primary"
                onClick={ sendBroadcast(NotificationMethod.Preferred) }
                loading={ loader === NotificationMethod.Preferred }
              >
                Send via Preferred Method
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
