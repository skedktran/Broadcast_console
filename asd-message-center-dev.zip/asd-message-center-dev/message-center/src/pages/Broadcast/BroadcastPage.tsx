import * as React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useHistory, useParams } from 'react-router-dom'
import { Button, DynamicModal, CalendarControls, RangeType, FilterBar } from '@skedulo/sked-ui'
import { startOfMonth, startOfDay, addDays, getDaysInMonth, endOfDay } from 'date-fns'

import { broadcastResourcesNewPath, broadcastResourcesPath, broadcastContactsNewPath, broadcastContactsPath } from '../routes'

import { BroadcastDetail } from '../../components/BroadcastDetail'
import SearchField from '../../components/SearchField'
import BroadcastTable from '../../components/BroadcastTable'
import { State, RecipientType } from '../../Store'
import { getBroadcasts } from '../../Store/reducerBroadcasts'
import { useFilters } from '../../Store/filters/useFilters'

import './BroadcastPage.scss'

interface Props {
  recipientType: RecipientType
}

type RangeFilterState = {
  selected: Date
  range: RangeType
}

const getEndDate = (date: Date, range: RangeType) => {
  switch (range) {
    case 'month': return addDays(date, getDaysInMonth(date))
    case '2-weeks': return addDays(date, 14)
    case 'week': return addDays(date, 7)
    case '3-days': return addDays(date, 3)
    case 'day': return endOfDay(date)
  }

  return endOfDay(date)
}

export const BroadcastPage: React.FC<Props> = ({ recipientType }) => {
  const dispatch = useDispatch()

  const [textFilter, setTextFilter] = React.useState('')
  const [rangeFilter, setRangeFilter] = React.useState<RangeFilterState>({
    selected: startOfMonth(new Date()),
    range: 'month'
  })

  const {
    filterOptions: broadcastsFilterOptions,
    onChange: broadcastsOnChange,
    filterString: broadcastsFilterString
  } = useFilters(recipientType === RecipientType.Resource ? 'BroadcastsResources' : 'BroadcastsContacts')

  React.useEffect(() => {
    dispatch(getBroadcasts({
      recipientType,
      start: rangeFilter.selected,
      end: getEndDate(rangeFilter.selected, rangeFilter.range),
      broadcastsFilter: broadcastsFilterString
    }))
  }, [recipientType, rangeFilter, broadcastsFilterString])

  const { UID: broadcastUID } = useParams()

  const broadcasts = useSelector((state: State) => state.broadcasts)
  const history = useHistory()

  const headerModal = () => (
    <div className="broadcast-detail__heading">
      <h1>Broadcast Details</h1>
    </div>
  )

  const footerModal = () => (
    <div className="broadcast-detail__footer">
      <Button
        buttonType="primary"
        onClick={ () => history.push(recipientType === RecipientType.Resource ? broadcastResourcesPath() : broadcastContactsPath()) }
      >Close
      </Button>
    </div>
  )

  return (
    <div className="broadcast-resource">
      {
        broadcastUID &&
        <DynamicModal
          className="broadcast-details-modal"
          header={ headerModal() }
          footer={ footerModal() }
        >
          <BroadcastDetail broadcastId={ broadcastUID } />
        </DynamicModal>
      }
      <div className="broadcast-resource__header">
        <div className="broadcast-resource__filters">
          { broadcastsFilterOptions && <FilterBar filters={ broadcastsFilterOptions } onFilter={ broadcastsOnChange } /> }
        </div>
        <Button
          buttonType="primary"
          compact={ false }
          disabled={ false }
          onClick={ () => history.push(recipientType === RecipientType.Resource
            ? broadcastResourcesNewPath()
            : broadcastContactsNewPath()) }
        >
          New Broadcast
        </Button>
      </div>
      <div className="broadcast-resource__table-controls">
        <div className="broadcast-resource__calendar-controls">
          <CalendarControls
            selected={ rangeFilter.selected }
            selectedRange={ rangeFilter.range }
            onTodayClick={ () => setRangeFilter({ ...rangeFilter, selected: startOfDay(new Date()) }) }
            onDateSelect={ selected => setRangeFilter({ ...rangeFilter, selected }) }
            onRangeChange={ range => setRangeFilter({ ...rangeFilter, range }) }
            rangeOptions={ ['day', '3-days', 'week', 'month'] }
          />
        </div>
        <SearchField onChange={ setTextFilter } />
      </div>
      <BroadcastTable
        broadcasts={ broadcasts }
        textFilter={ textFilter }
        recipientType={ recipientType }
        className="broadcast-resource__table"
        paginationClassName="broadcast-resource__pagination"
      />
    </div>
  )
}
