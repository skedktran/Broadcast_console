export const basePath = () => '/'

export const broadcastResourcesPath = () => '/broadcast-resources'
export const broadcastResourcesNewPath = ({ preselectedResourceIds = [], config = false } = { preselectedResourceIds: [] as string[], config: false as boolean }) => {
  const base = '/broadcast-resources/new'
  if (config) return `${base}/:preselectedResourceIds?`

  return preselectedResourceIds.length
    ? `${base}/${JSON.stringify(preselectedResourceIds)}?`
    : base
}
export const broadcastResourcesSummaryPath = (UID = ':UID') => `/broadcast-resources/summary/${UID}`
export const broadcastResourcesDetailsPath = (UID = ':UID') => `/broadcast-resources/details/${UID}`


export const broadcastContactsPath = () => '/broadcast-contacts'
export const broadcastContactsNewPath = ({ preselectedContactIds = [], config = false } = { preselectedContactIds: [] as string[], config: false as boolean }) => {
  const base = '/broadcast-contacts/new'
  if (config) return `${base}/:preselectedContactIds?`

  return preselectedContactIds.length
    ? `${base}/${JSON.stringify(preselectedContactIds)}?`
    : base
}
export const broadcastContactsSummaryPath = (UID = ':UID') => `/broadcast-contacts/summary/${UID}`
export const broadcastContactsDetailsPath = (UID = ':UID') => `/broadcast-contacts/details/${UID}`
