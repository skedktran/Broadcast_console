import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import { getContacts } from '../../Store/reducerContacts'
import { State } from '../../Store'

export const BroadcastContactsPage: React.FC = () => {
  const dispatch = useDispatch()
  useEffect(() => {
    dispatch(getContacts())
  }, [])

  const contacts = useSelector((state: State) => state.contacts)

  return (
    <div>
      Message Contact Page
      <ul>
        {
          contacts.map(contact => (
            <li key={ contact.UID }>
              { contact.FullName }
            </li>
          ))
        }
      </ul>
    </div>
  )
}
