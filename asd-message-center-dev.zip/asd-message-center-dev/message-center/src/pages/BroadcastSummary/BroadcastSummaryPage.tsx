import * as React from 'react'
import { useHistory, useParams } from 'react-router-dom'
import { Button } from '@skedulo/sked-ui'
import { useDispatch } from 'react-redux'

import { RecipientType } from '../../Store'
import { BackBar } from '../../components/BackBar'
import { BroadcastDetail } from '../../components/BroadcastDetail'
import { RecipientsListBox } from '../../components/RecipientsListBox/RecipientsListBox'

import {
  broadcastResourcesPath,
  broadcastResourcesNewPath,
  broadcastContactsPath,
  broadcastContactsNewPath
} from '../routes'
import { getBroadcastById } from '../../Store/reducerBroadcasts'

import './BroadcastSummaryPage.scss'

interface Props {
  recipientType: RecipientType
}

export const BroadcastSummary: React.FC<Props> = ({ recipientType }) => {
  const history = useHistory()
  const { UID: broadcastUID } = useParams()

  const dispatch = useDispatch()
  React.useEffect(() => {
    dispatch(getBroadcastById(broadcastUID))
  }, [])

  return (
    <div className="broadcast-summary-page">
      <div className="broadcast-summary-page__backbar">
        <BackBar
          route={ recipientType === RecipientType.Resource ? broadcastResourcesPath() : broadcastContactsPath() }
        />
      </div>
      <div className="broadcast-summary-page__detail">
        <BroadcastDetail broadcastId={ broadcastUID } />
        <div className="broadcast-summary-page__buttons">
          <Button
            buttonType="secondary"
            icon={ null }
            onClick={ () => history.push(recipientType === RecipientType.Resource ? broadcastResourcesPath() : broadcastContactsPath()) }
          >
            All broadcasts
          </Button>
          <Button
            buttonType="primary"
            icon={ null }
            onClick={ () => history.push(recipientType === RecipientType.Resource ? broadcastResourcesNewPath() : broadcastContactsNewPath()) }
          >
            Create new broadcast
          </Button>
        </div>
      </div>
      <RecipientsListBox
        type={ recipientType }
        searchClassName="broadcast-summary-page__search"
        className="broadcast-summary-page__resources"
        headerTitle="sent to:"
      />
    </div>
  )
}
