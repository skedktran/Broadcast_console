import * as React from 'react'
import { FormInputElement, AvatarDetail, Button } from '@skedulo/sked-ui'
import { useDispatch } from 'react-redux'
import { FixedSizeList as List } from 'react-window'
import AutoSizer from 'react-virtualized-auto-sizer'
import { useRecipients } from '../../hooks/useRecipients'

import { setSelection } from '../../Store/reducerNewPage'

import './RecipientsListBox.scss'
import SearchField from '../SearchField'
import { RecipientType } from '../../Store'

interface Props {
  type: RecipientType
  headerTitle: string
  footer?: boolean
  selectable?: boolean
  className?: string
  searchClassName?: string
  search?: boolean
}

export const RecipientsListBox: React.FC<Props> = React.memo(({ type, headerTitle, footer, selectable, className, searchClassName, search }) => {
  const dispatch = useDispatch()

  const [recipients, selectedRecipients] = useRecipients(type)
  const [searchString, setSearchString] = React.useState('')
  const [visibleResources, setVisibleResources] = React.useState([...recipients])

  React.useEffect(() => {
    setSearchString('')
  }, [recipients])
  React.useEffect(() => {
    setVisibleResources(searchString
      ? recipients.filter(({ Name }) => Name.toLowerCase().includes(searchString.toLowerCase()))
      : recipients)
  }, [recipients, searchString])
  const itemCount = visibleResources.length

  return (
    <>
      <div className={ searchClassName }>{search && <SearchField value={ searchString } onChange={ e => setSearchString(e) } />}</div>
      <div className={ className }>
        <div className="list">
          <div className="list__header list-header">
            <span className="list-header__text-content">{headerTitle}</span>
            <span className="list-header__elements" />
          </div>
          <div className="list__list">
            <AutoSizer>
              {({ height, width }) => (
                <List
                  innerElementType="ul"
                  height={ height }
                  itemCount={ itemCount }
                  itemSize={ 50 }
                  width={ width }
                >
                  {({ index, style }) => {
                    const recipient = visibleResources[index]
                    return selectable ? (
                      <li
                        key={ recipient.UID }
                        style={ style }
                        className={ `list__element ${selectedRecipients.includes(recipient.UID) ? 'list__element--selected' : ''}` }
                        onClick={ () => dispatch(setSelection(type, selectedRecipients.includes(recipient.UID)
                          ? selectedRecipients.filter(UID => UID !== recipient.UID)
                          : [...selectedRecipients, recipient.UID])) }
                      >
                        <SelectableListElement type={ type } UID={ recipient.UID } />
                      </li>
                    ) : (
                      <li
                        key={ recipient.UID }
                        className="list__element list__element--selected"
                        style={ style }
                      >
                        <ResourceListElement type={ type } UID={ recipient.UID } />
                      </li>
                    )
                  }}
                </List>
              )}
            </AutoSizer>
          </div>

          {/* <ul className="list__list">
            {visibleResources.map(recipient => selectable ? (
              <li
                key={ recipient.UID }
                className={ `list__element ${selectedRecipients.includes(recipient.UID) ? 'list__element--selected' : ''}` }
                onClick={ () => dispatch(setSelection(type, selectedRecipients.includes(recipient.UID)
                  ? selectedRecipients.filter(UID => UID !== recipient.UID)
                  : [...selectedRecipients, recipient.UID])) }
              >
                <SelectableListElement type={ type } UID={ recipient.UID } />
              </li>
            ) : (
              <li
                key={ recipient.UID }
                className="list__element list__element--selected"
              >
                <ResourceListElement type={ type } UID={ recipient.UID } />
              </li>
            ))}
          </ul> */}
          {
            footer && <Footer type={ type } />
          }
        </div>
      </div>
    </>
  )
})

const SelectableListElement: React.FC<{ UID: string, type: RecipientType }> = React.memo(({ UID, type }) => {
  const selectedResources = useRecipients(type)[1]
  const checked = selectedResources.includes(UID)

  return (
    <>
      <FormInputElement
        id={ UID }
        type="checkbox"
        checked={ checked }
      />
      <div className="list__element-label">
        <ResourceListElement type={ type } UID={ UID } />
      </div>
    </>
  )
})

const ResourceListElement: React.FC<{ UID: string, type: RecipientType }> = React.memo(({ UID, type }) => {
  // const resource = useSelector((state: State) => state.resources.find(({ UID: storeUID }) => storeUID === UID))
  const [recipients] = useRecipients(type)
  const theRecipient = recipients.find(({ UID: storeUID }) => storeUID === UID)
  if (!theRecipient) {
    return null
  }
  const { Name, Avatar, Category } = theRecipient
  return <AvatarDetail
    name={ Name }
    imageUrl={ Avatar }
    subtitle={ <span>{Category}</span> }
    size="medium"
  />
})

const Footer: React.FC<{ type: RecipientType }> = React.memo(({ type }) => {
  const dispatch = useDispatch()
  const [recipients, selectedRecipients] = useRecipients(type)
  return (
    <div className="list__footer list-footer">
      <span className="list-footer__text-content">selected: {selectedRecipients.length}</span>
      <span className="list-footer__elements">
        <Button
          onClick={ () => dispatch(setSelection(type, [])) }
          className="list-footer__button"
          buttonType="transparent"
          compact
        >
          Deselect All
        </Button>
        <Button
          onClick={ () => dispatch(setSelection(type, recipients.map(({ UID }) => UID))) }
          className="list-footer__button list-footer__button--blue"
          buttonType="transparent"
          compact
        >
          Select All
        </Button>
      </span>
    </div>
  )
})
