import React, { useState, useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { useHistory } from 'react-router-dom'
import { StatusIcon, Icon } from '@skedulo/sked-ui'

import { RecipientsList, Recipient as RecipientsListItem } from './RecipientsList'
import { BroadcastSummary } from './BroadcastSummary'
import { BroadcastDetailHeader } from './BroadcastDetailHeader'
import { State, Broadcast, BroadcastStatus, RecipientType, NotificationMethod } from '../../Store'
import {
  rebroadcastResources,
  rebroadcastContacts,
  getBroadcastById
} from '../../Store/reducerBroadcasts'
import { broadcastResourcesNewPath, broadcastContactsNewPath } from '../../pages/routes'

import './BroadcastDetail.scss'

interface ListItem extends RecipientsListItem {
  status: BroadcastStatus
  resourceId?: string
  contactId?: string
}

const selectBroadcastRecipients = (state: State, broadcast: Broadcast) => {
  if (!broadcast) return []

  return broadcast.RecipientIds
    .map(id => state.broadcastRecipients[id])
    .filter(recipient => !!recipient)
}

const selectResourceTypeRecipientListItems = (state: State, broadcast: Broadcast) => {
  const recipients = selectBroadcastRecipients(state, broadcast)
  const resources = state.resources

  return recipients.reduce((acc, recipient) => {
    const resource = resources.find(({ UID }) => UID === recipient.ResourceId)
    return [
      ...acc,
      {
        id: recipient.UID,
        name: resource?.Name,
        avatar: resource?.Avatar,
        notificationMethod: recipient?.NotificationMethod,
        phone: resource?.MobilePhone,
        status: recipient.Status,
        resourceId: resource?.UID,
        contactId: null,
        loading: false
      }
    ]
  }, [])
}

const selectContactTypeRecipientListItems = (state: State, broadcast: Broadcast) => {
  const recipients = selectBroadcastRecipients(state, broadcast)
  const contacts = state.contacts

  return recipients.reduce((acc, recipient) => {
    const contact = contacts.find(({ UID }) => UID === recipient.ContactId)
    return [
      ...acc,
      {
        id: recipient.UID,
        name: contact?.FullName,
        avatar: null,
        notificationMethod: null,
        phone: contact?.MobilePhone,
        status: recipient.Status,
        resourceId: null,
        contactId: contact?.UID,
        loading: false
      }
    ]
  }, [])
}

const selectRecipientListItems = (state: State, broadcast: Broadcast) => {
  switch (broadcast?.RecipientType) {
    case RecipientType.Resource: return selectResourceTypeRecipientListItems(state, broadcast)
    case RecipientType.Contact: return selectContactTypeRecipientListItems(state, broadcast)
    default: return []
  }
}

interface Props {
  broadcastId: string
}

export const BroadcastDetail: React.FC<Props> = props => {
  const broadcast = useSelector((state: State) => state.broadcasts.find(({ UID }) => UID === props.broadcastId))
  const state = useSelector((state: State) => state)
  const [recipientItems, setRecipientItems] = useState([] as ListItem[])

  useEffect(() => {
    setRecipientItems(selectRecipientListItems(state, broadcast))
  }, [broadcast, state.broadcastRecipients, state.resources, state.contacts])

  const [unsentListExpanded, setUnsentListExpanded] = useState(true)
  const [allListExpanded, setAllListExpanded] = useState(false)

  const dispatch = useDispatch()
  const history = useHistory()

  if (!broadcast) return <div>No broadcast</div>

  const unsentRecipientItems = recipientItems.filter(item => item.status === BroadcastStatus.Error)

  const setRecipientsLoading = (recipientIds: string[], loading: boolean) => {
    setRecipientItems(recipientItems.map(item => (
      recipientIds.includes(item.id) ? { ...item, loading } : item
    )))
  }

  const setRecipientNotificationMethod = (recipientId: string, notificationMethod: NotificationMethod) => {
    setRecipientItems(recipientItems.map(item => (
      item.id === recipientId ? { ...item, notificationMethod } : item
    )))
  }

  const resend = (recipientIds: string[]) => {
    setRecipientsLoading(recipientIds, true)
    if (broadcast.RecipientType === RecipientType.Resource) {
      dispatch(rebroadcastResources(
        broadcast.UID,
        recipientIds,
        recipientIds.reduce((acc, id) => ({
          ...acc,
          [id]: recipientItems.find(item => item.id === id)?.notificationMethod
        }), {}),
        () => dispatch(getBroadcastById(broadcast.UID))
      ))
    } else if (broadcast.RecipientType === RecipientType.Contact) {
      dispatch(rebroadcastContacts(
        broadcast.UID,
        recipientIds,
        () => dispatch(getBroadcastById(broadcast.UID))
      ))
    }
  }

  return (
    <div className="broadcast-detail">
      <div className="broadcast-detail__header">
        <BroadcastDetailHeader
          notSentCount={ broadcast.NotSent }
          totalCount={ broadcast.TotalRecipients }
          recipients={ recipientItems.map(({ name, avatar }) => ({ name, avatar })) }
          resendCallback={ () => resend(unsentRecipientItems.map(recipient => recipient.id)) }
        />
      </div>
      <div className="broadcast-detail__body">
        <div className="broadcast-detail__summary">
          <BroadcastSummary content={ broadcast.Broadcast } date={ broadcast.Date } />
        </div>
        {
          broadcast.NotSent > 0 &&
          <div className="broadcast-detail__unsent">
            <RecipientsList
              expanded={ unsentListExpanded }
              onExpandToggle={ () => setUnsentListExpanded(!unsentListExpanded) }
              headerIcon={ <StatusIcon status="warning" /> }
              headerLabel="Unsent"
              batchActionLabel="Resend All"
              batchActionCallback={ recipientIds => resend(recipientIds) }
              itemActionLabel="Resend"
              itemActionCallback={ recipientId => resend([recipientId]) }
              recipients={ unsentRecipientItems }
              type={ broadcast.RecipientType }
              onItemNotificationMethodChange={ setRecipientNotificationMethod }
            />
          </div>
        }
        <div className="broadcast-detail__all-recipients">
          <RecipientsList
            expanded={ allListExpanded }
            onExpandToggle={ () => setAllListExpanded(!allListExpanded) }
            headerIcon={ <Icon name="resource" className="broadcast-detail__all-recipients-icon" /> }
            headerLabel="All recipients"
            batchActionLabel="Send new broadcast to recipients"
            batchActionCallback={
              () => history.push(broadcast.RecipientType === RecipientType.Resource
                ? broadcastResourcesNewPath({ preselectedResourceIds: recipientItems.map(item => item.resourceId) })
                : broadcastContactsNewPath({ preselectedContactIds: recipientItems.map(item => item.contactId) }))
            }
            recipients={ recipientItems }
            type={ broadcast.RecipientType }
          />
        </div>
      </div>
    </div>
  )
}
