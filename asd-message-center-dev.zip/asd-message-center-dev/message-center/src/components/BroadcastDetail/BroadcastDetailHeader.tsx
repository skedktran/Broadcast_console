import React from 'react'
import { StatusIcon } from '@skedulo/sked-ui'
import { AvatarGroup } from '../AvatarGroup'

interface Props {
  notSentCount: number
  totalCount: number
  recipients: {
    avatar: string
    name: string
  }[]
  resendCallback: () => void
}

export const BroadcastDetailHeader: React.FC<Props> = ({ notSentCount, totalCount, recipients, resendCallback }) => (
  <div className="broadcast-detail-header">
    <AvatarGroup
      users={ recipients }
      maxAvatarsVisible={ 3 }
    />
    {
      notSentCount > 0
        ? (
          <div className="broadcast-detail-header__banner broadcast-detail-header__banner--warning">
            <span className="broadcast-detail-header__banner-icon">
              <StatusIcon status="warning" />
            </span>
            { notSentCount } of { totalCount } broadcasts were not delivered successfully.
            <span
              className="broadcast-detail-header__resend"
              onClick={ resendCallback }
            >
              Resend?
            </span>
          </div>
        )
        : (
          <div className="broadcast-detail-header__banner broadcast-detail-header__banner--success">
            <span className="broadcast-detail-header__banner-icon">
              <StatusIcon status="success" />
            </span>
            Broadcast sent successfully to all recipients
          </div>
        )
      }
  </div>
)
