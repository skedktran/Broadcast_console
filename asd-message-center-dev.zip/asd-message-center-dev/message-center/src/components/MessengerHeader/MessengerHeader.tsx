import React from 'react'
import { useSelector } from 'react-redux'
import { AvatarDetail, StatusIcon } from '@skedulo/sked-ui'

import { State, NotificationMethod } from '../../Store'
import { AvatarGroup } from '../AvatarGroup'

import './MessengerHeader.scss'

export const MessengerHeader: React.FC = () => {
  let content = null
  const resources = useSelector(({ selectedResources, allResources }: State) => selectedResources.map(UID => allResources[UID]))

  if (resources.length === 1) {
    const { Name, Avatar, NotificationType, Category } = resources[0]
    content = (<SingleHeader
      name={ Name }
      description={ Category }
      preferredMethod={ NotificationType }
      avatarUrl={ Avatar }
    />)
  }
  if (resources.length > 1) {
    const users = resources.map(({ Name, Avatar }) => ({ name: Name, avatar: Avatar }))
    const smsNumber = resources.reduce((acc, { NotificationType }) => NotificationType === NotificationMethod.SMS ? acc + 1 : acc, 0)
    content = (
      <>
        <AvatarGroup users={ users } maxAvatarsVisible={ 4 } />
        { !!smsNumber && <StatusBar number={ smsNumber } /> }
      </>
    )
  }
  return (
    <div className="messenger-header">
      {content}
    </div>
  )
}

export const ContactsMessengerHeader: React.FC = () => {
  let content = null
  const contacts = useSelector(({ selectedContacts, allContacts }: State) => selectedContacts.map(UID => allContacts[UID]))

  if (contacts.length === 1) {
    const { FullName } = contacts[0]
    content = (
      <>
        <SingleHeader
          name={ FullName }
        />
        <div style={ { fontSize: '14px' } } className="broadcast-detail-header__banner broadcast-detail-header__banner--warning">
          <span className="broadcast-detail-header__banner-icon">
            <StatusIcon status="warning" />
          </span>
          Contact will be notified by SMS
        </div>
      </>
    )
  }
  if (contacts.length > 1) {
    const users = contacts.map(({ FullName }) => ({ name: FullName, avatar: null }))
    content = (
      <>
        <AvatarGroup users={ users } maxAvatarsVisible={ 4 } />
        <div style={ { fontSize: '14px' } } className="broadcast-detail-header__banner broadcast-detail-header__banner--warning">
          <span className="broadcast-detail-header__banner-icon">
            <StatusIcon status="warning" />
          </span>
          {contacts.length} Contacts will be notified by SMS
        </div>
      </>
    )
  }
  return (
    <div className="messenger-header">
      {content}
    </div>
  )
}

interface MessengerHeaderProps {
  name: string
  description?: string
  preferredMethod?: string
  avatarUrl?: string
}

const SingleHeader: React.FC<MessengerHeaderProps> = ({
  name,
  description,
  preferredMethod,
  avatarUrl
}) => (
  <>
    <AvatarDetail
      name={ name }
      imageUrl={ avatarUrl }
      subtitle={ <span>{ description || '' }</span> }
      size="medium"
    />
    {preferredMethod &&
    <div style={ { fontSize: '14px' } } className="broadcast-detail-header__banner broadcast-detail-header__banner--warning">
      <span className="broadcast-detail-header__banner-icon">
        <StatusIcon status="warning" />
      </span>
      Resource will be notified by {preferredMethod} if sent by the preferred notification method
    </div>}
  </>
)

const StatusBar: React.FC<{number: number}> = ({ number }) => {
  return (
    <div style={ { fontSize: '14px' } } className="broadcast-detail-header__banner broadcast-detail-header__banner--warning">
      <span className="broadcast-detail-header__banner-icon">
        <StatusIcon status="warning" />
      </span>
      {number} {number === 1 ? "Resource" : "Resources"} will be notified by SMS if sent by the preferred notification method
    </div>)
}

export default MessengerHeader
