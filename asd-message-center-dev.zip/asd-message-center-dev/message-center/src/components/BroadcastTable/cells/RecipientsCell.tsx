import React from 'react'
import { useSelector } from 'react-redux'
import { State } from '../../../Store'
import { AvatarGroup } from '../../AvatarGroup'

type Props = {
  recipientIds: string[]
}

const RecipientsCell: React.FC<Props> = ({ recipientIds }) => {
  const users = useSelector(({ allResources, allContacts, broadcastRecipients }: State) => recipientIds.map((recipientId: string) => {
    const { ResourceId, ContactId } = broadcastRecipients[recipientId]
    if (ResourceId && allResources[ResourceId]) {
      const { Avatar, Name } = allResources[ResourceId]
      return {
        avatar: Avatar || null,
        name: Name
      }
    }
    if (ContactId && allContacts[ContactId]) {
      const { FullName } = allContacts[ContactId]
      return {
        avatar: null,
        name: FullName
      }
    }
    return {
      avatar: null,
      name: ''
    }
  }))

  return (
    <>
      <div>
        <AvatarGroup users={ users } maxAvatarsVisible={ 2 } />
      </div>
    </>
  )
}

export default RecipientsCell
