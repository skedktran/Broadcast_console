import { CustomFieldType } from './utils'

import { ResourcesSearchQuery, ContactsSearchQuery } from '../queries'
import { Services } from '../../Services/Services'

export type FilterableObjectName = 'Resources' | 'Contacts' | 'BroadcastsResources' | 'BroadcastsContacts'

export enum FilterOperator {
  AND = 'AND',
  OR = 'OR'
}

export enum FilterType {
  baseObject,
  vocabulary,
  custom,
  fetch,
  fixed
}

export declare type FilterInputType = 'checkbox' | 'radio'

export type FilterConfigInstance = {
  operator: FilterOperator
  customFields: boolean
  baseFilter?: string
  filters: FiltersConfigOption[]
}

export type IFiltersConfig = {
  [key in FilterableObjectName]: FilterConfigInstance
}

export interface FilterBarFilterItem {
  id: string
  name: string
  fieldType?: CustomFieldType
}

export interface FiltersConfigOption {
  type: FilterType
  name: string
  label: string
  labelField?: string
  keyField?: string
  fieldType?: CustomFieldType
  items? : {
    id: string
    name: string
  }[]
  inputType: FilterInputType
  filterString: (filterVariables: string) => string
  fetchFunction?: (searchTerm: string) => Promise<{
    id: string
    name: string
}[]>

  schemaName?: string
}

type FilterResponse = {
  id: string
  name: string
}

const ResourceFilterFetch = (searchString: string) => {
  const getSearchListElements = new Promise<FilterResponse[]>(resolve => {
    Services.graphQL.fetch<{resources: FilterResponse[]}>({
      query: ResourcesSearchQuery,
      variables: {
        filter: `Name LIKE "%${searchString}%"`
      }
    }).then(resp => {
      resolve(resp.resources)
    })
  })
  return getSearchListElements
}
const ContactFilterFetch = (searchString: string) => {
  const getSearchListElements = new Promise<FilterResponse[]>(resolve => {
    Services.graphQL.fetch<{contacts: FilterResponse[]}>({
      query: ContactsSearchQuery,
      variables: {
        filter: `FullName LIKE "%${searchString}%"`
      }
    }).then(resp => {
      resolve(resp.contacts)
    })
  })
  return getSearchListElements
}

export const filtersConfig: IFiltersConfig = {
  Resources: {
    operator: FilterOperator.AND,
    customFields: true,
    baseFilter: "IsActive == true AND ResourceType == 'Person'",
    filters: [
      {
        type: FilterType.baseObject,
        name: 'tags',
        label: 'Tags',
        labelField: 'Name',
        keyField: 'UID',
        inputType: 'checkbox',
        filterString: (vars: string) => `(UID IN (SELECT ResourceId FROM ResourceTags WHERE (TagId IN [${vars}])))`
      },
      {
        type: FilterType.baseObject,
        name: 'regions',
        label: 'Region',
        labelField: 'Name',
        keyField: 'UID',
        inputType: 'checkbox',
        filterString: (vars: string) => `PrimaryRegionId IN [${vars}]`
      },
      {
        type: FilterType.vocabulary,
        name: 'Category',
        label: 'Resource Category',
        inputType: 'checkbox',
        schemaName: 'Resources',
        filterString: (vars: string) => `Category IN [${vars}]`
      }
    ]
  },
  Contacts: {
    operator: FilterOperator.AND,
    customFields: false,
    baseFilter: 'MobilePhone != null',
    filters: [
      {
        type: FilterType.baseObject,
        name: 'regions',
        label: 'Region',
        labelField: 'Name',
        keyField: 'UID',
        inputType: 'checkbox',
        filterString: (vars: string) => `RegionId IN [${vars}]`
      },
      {
        type: FilterType.baseObject,
        name: 'tags',
        label: 'Tags',
        labelField: 'Name',
        keyField: 'UID',
        inputType: 'checkbox',
        filterString: (vars: string) => `(UID IN (SELECT ContactId FROM ContactTags WHERE (TagId IN [${vars}])))`
      }
    ]
  },
  BroadcastsResources: {
    operator: FilterOperator.AND,
    customFields: false,
    filters: [
      {
        type: FilterType.fixed,
        name: 'sked_NotificationMethod',
        label: 'Method',
        inputType: 'checkbox',
        schemaName: 'sked_Broadcasts',
        items: [{
          id: 'SMS',
          name: 'SMS'
        }, {
          id: 'Push',
          name: 'Push'
        }, {
          id: 'PreferredNotificationMethod',
          name: 'Preferred Notification Method'
        }],
        filterString: (vars: string) => `sked_NotificationMethod IN [${vars}]`
      },
      {
        type: FilterType.fetch,
        name: 'Resource',
        label: 'Resource',
        inputType: 'checkbox',
        fetchFunction: ResourceFilterFetch,
        filterString: (vars: string) => `UID IN (SELECT sked_BroadcastId FROM sked_BroadcastRecipients WHERE (sked_ResourceId IN [${vars}]))`
      }
    ]
  },
  BroadcastsContacts: {
    operator: FilterOperator.AND,
    customFields: false,
    filters: [
      {
        type: FilterType.fetch,
        name: 'Contact name',
        label: 'Contact Name',
        inputType: 'checkbox',
        fetchFunction: ContactFilterFetch,
        filterString: (vars: string) => `UID IN (SELECT sked_BroadcastId FROM sked_BroadcastRecipients WHERE (sked_ContactId IN [${vars}]))`
      }
    ]
  }
}
