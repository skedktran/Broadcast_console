export const BroadcastRecipientsQuery = `
query getBroadcastRecipients($recipientsFilter: EQLQueryFiltersked_BroadcastRecipients, $first: PositiveIntMax200, $offset:  NonNegativeInt, $orderBy: EQLOrderByClausesked_BroadcastRecipients) {
  broadcastRecipients: sked_BroadcastRecipients(filter: $recipientsFilter, first: $first, orderBy: $orderBy, offset: $offset) {
    pageInfo {
      hasNextPage
    }
    totalCount
    edges {
      node {
        UID
        Date: sked_Date
        Phone: sked_Phone
        Status: sked_Status
        ContactId: sked_ContactId
        ResourceId: sked_ResourceId
        BroadcastId: sked_BroadcastId
        Timestamp: sked_Timestamp
        ErrorInformation: sked_ErrorInformation
        NotificationMethod: sked_NotificationMethod
      }
    }
  }
}
`
