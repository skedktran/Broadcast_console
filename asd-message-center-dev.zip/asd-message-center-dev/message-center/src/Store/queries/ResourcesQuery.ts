export const ResourcesQuery = `
query getResources ($filter: EQLQueryFilterResources, $first: PositiveIntMax200, $offset:  NonNegativeInt, $orderBy: EQLOrderByClauseResources) {
  resources (filter: $filter, first: $first, orderBy: $orderBy, offset: $offset) {
    totalCount
    edges {
      node {
        UID
        Name
        User {
          UID
        }
        NotificationType
        MobilePhone
        PrimaryRegionId
        Category
      }
    }
  }
}
`
