export const ContactsQuery = `
query getContacts ($filter: EQLQueryFilterContacts, $first: PositiveIntMax200, $offset:  NonNegativeInt, $orderBy: EQLOrderByClauseContacts) {
  contacts (filter: $filter, first: $first, orderBy: $orderBy, offset: $offset) {
    totalCount
    edges {
      node {
        UID
        FullName
        MobilePhone
      }
    }
  }
}
`
