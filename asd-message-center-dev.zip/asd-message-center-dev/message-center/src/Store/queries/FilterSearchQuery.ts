export const ResourcesSearchQuery = `
query getSearchResources ($filter: EQLQueryFilterResources, $first: PositiveIntMax200, $offset:  NonNegativeInt) {
  resources (filter: $filter, first: $first, orderBy: "UID", offset: $offset) {
    totalCount
    edges {
      node {
        id: UID
        name: Name
      }
    }
  }
}
`
export const ContactsSearchQuery = `
query getSearchContacts ($filter: EQLQueryFilterContacts, $first: PositiveIntMax200, $offset:  NonNegativeInt) {
  contacts (filter: $filter, first: $first, orderBy: "UID", offset: $offset) {
    totalCount
    edges {
      node {
        id: UID
        name: FullName
      }
    }
  }
}
`
