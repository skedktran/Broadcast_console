export const BroadcastsQuery = `
query getBroadcasts($broadcastsFilter: EQLQueryFiltersked_Broadcasts, $first: PositiveIntMax200, $offset:  NonNegativeInt) {
  broadcasts: sked_Broadcasts(filter: $broadcastsFilter, orderBy: "sked_Timestamp DESC", first: $first, offset: $offset) {
    pageInfo {
      hasNextPage
    }
    totalCount
    edges {
      node {
        UID
        Broadcast: sked_Broadcast
        Date: sked_Date
        NotificationMethod: sked_NotificationMethod
        RecipientType: sked_RecipientType
        Timestamp: sked_Timestamp
        RecipientType: sked_RecipientType
        Sent: sked_Sent
        NotSent: sked_NotSent
        TotalRecipients: sked_TotalRecipients
      }
    }
  }
}
`
