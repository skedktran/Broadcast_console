import { Dispatch } from 'redux'
import { autoPaginationGraphqlRequest } from '../../Services/GraphQLServices'
import {
  makeActionsSet,
  makeReducers,
  makeAsyncActionCreatorSimp,
  makeActionCreator
} from '../../common/utils/redux-helpers'

import * as Queries from '../queries'
import { Services } from '../../Services/Services'
import {
  Broadcast,
  BroadcastRecipient,
  RecipientType,
  State
} from '../types'
import { getResources } from '../reducerResources'
import { getContacts } from '../reducerContacts'

const BROADCASTS_GET = makeActionsSet('BROADCASTS_GET')
const BROADCASTS_CLEAR = 'BROADCASTS_CLEAR'
const SINGLE_BROADCAST_GET = makeActionsSet('SINGLE_BROADCAST_GET')

export const getDefaultBroadcasts = () => [] as Broadcast[]
export const getDefaultRecipients = () => ({} as { [recipientId: string]: BroadcastRecipient })

export const clearBroadcasts = makeActionCreator(BROADCASTS_CLEAR)

export const getBroadcasts = makeAsyncActionCreatorSimp(
  BROADCASTS_GET, (filters: {
    recipientType?: RecipientType
    start?: Date
    end?: Date
    broadcastsFilter?: string
    recipientsFilter?: string
  } = {}) => async (dispatch: Dispatch) => {
    dispatch(clearBroadcasts())

    const broadcastsFilter = [
      filters.recipientType ? `sked_RecipientType == "${filters.recipientType}"` : null,
      filters.start ? `sked_Timestamp > "${filters.start.getTime()}"` : null,
      filters.end ? `sked_Timestamp < "${filters.end.getTime()}"` : null,
      filters.broadcastsFilter || null
    ].filter(filter => filter !== null)
      .join(' AND ') || null

    const broadcasts = await autoPaginationGraphqlRequest<Broadcast>(Queries.BroadcastsQuery, 'broadcasts', {
      broadcastsFilter
    }, ['UID'])

    const recipientsFilter = [
      filters.recipientType ? `sked_Broadcast.sked_RecipientType == "${filters.recipientType}"` : null,
      filters.recipientsFilter || null,
      broadcasts.length ? `sked_BroadcastId IN ${JSON.stringify(broadcasts.map(item => item.UID))}` : null
    ].filter(filter => filter !== null)
      .join(' AND ') || null

    let broadcastRecipients: BroadcastRecipient[] = []
    if (recipientsFilter) {
      const recipientsResp = await autoPaginationGraphqlRequest<BroadcastRecipient>(Queries.BroadcastRecipientsQuery, 'broadcastRecipients', {
        recipientsFilter
      }, ['UID'])

      broadcastRecipients = recipientsResp || []
    }

    const resources = broadcastRecipients.reduce(
      (acc, { ResourceId }) => {
        if (ResourceId && !acc.includes(ResourceId)) {
          acc.push(ResourceId)
        }
        return acc
      }, []
    )
    if (resources.length) {
      dispatch(getResources({
        filter: `UID IN ${JSON.stringify(resources)}`
      }))
    }

    const contacts = broadcastRecipients.reduce(
      (acc, { ContactId }) => {
        if (ContactId && !acc.includes(ContactId)) {
          acc.push(ContactId)
        }
        return acc
      }, []
    )
    if (contacts.length) {
      dispatch(getContacts({
        filter: `UID IN ${JSON.stringify(contacts)}`
      }))
    }

    return {
      broadcasts,
      broadcastRecipients
    }
  }
)

export const getBroadcastById = makeAsyncActionCreatorSimp(
  SINGLE_BROADCAST_GET, (id: string) => async (dispatch: Dispatch) => {
    const resp = await Services.graphQL.fetch<{ broadcast: Broadcast, broadcastRecipients: BroadcastRecipient[] }>({
      query: Queries.SingleBroadcastQuery,
      variables: {
        id,
        recipientsFilter: `sked_BroadcastId == "${id}"`
      }
    })

    if (resp.broadcast.RecipientType === RecipientType.Resource) {
      const resourceIds = resp.broadcastRecipients
        .map(recipient => recipient.ResourceId)
        .filter(id => !!id)
      dispatch(getResources({ filter: `UID IN [${resourceIds.map(id => `"${id}"`).join(', ')}]` }))
    } else if (resp.broadcast.RecipientType === RecipientType.Contact) {
      const contactIds = resp.broadcastRecipients
        .map(recipient => recipient.ContactId)
        .filter(id => !!id)
      dispatch(getContacts({ filter: `UID IN [${contactIds.map(id => `"${id}"`).join(', ')}]` }))
    }

    return {
      broadcasts: [resp.broadcast],
      broadcastRecipients: resp.broadcastRecipients
    }
  }
)

const transformToIndexedDataStructures = (result: {
  broadcasts: Broadcast[]
  broadcastRecipients: BroadcastRecipient[]
}) => {
  const broadcasts = result.broadcasts.reduce((acc, broadcast) => ({
    ...acc,
    [broadcast.UID]: {
      ...broadcast,
      RecipientIds: []
    }
  }), {} as { [broadcastId: string]: Broadcast })

  result.broadcastRecipients.forEach(recipient => {
    const broadcast = broadcasts[recipient.BroadcastId]
    if (broadcast) {
      broadcast.RecipientIds.push(recipient.UID)
    }
  })

  const broadcastRecipients = result.broadcastRecipients.reduce((acc, recipient) => ({
    ...acc,
    [recipient.UID]: recipient
  }), {} as { [recipientId: string]: BroadcastRecipient })

  return {
    broadcasts,
    broadcastRecipients
  }
}

const broadcastsTransform = (result: {
  broadcasts: Broadcast[]
  broadcastRecipients: BroadcastRecipient[]
}) => {
  const { broadcasts, broadcastRecipients } = transformToIndexedDataStructures(result)

  return {
    broadcasts: Object.values(broadcasts),
    broadcastRecipients
  }
}

const additiveBroadcastsTransform = (
  result: {
    broadcasts: Broadcast[]
    broadcastRecipients: BroadcastRecipient[]
  },
  state: State
) => {
  const { broadcasts, broadcastRecipients } = broadcastsTransform(result)

  const newBroadcasts = [...state.broadcasts]

  broadcasts.forEach(broadcast => {
    const index = newBroadcasts.findIndex(({ UID }) => broadcast.UID === UID)
    if (index === -1) {
      newBroadcasts.push(broadcast)
    } else {
      newBroadcasts[index] = broadcast
    }
  })
  newBroadcasts.sort((broadcast1, broadcast2) => (broadcast1.Timestamp < broadcast2.Timestamp) ? 1 : -1)

  const newBroadcastRecipients = {
    ...state.broadcastRecipients,
    ...broadcastRecipients
  }

  return {
    broadcasts: newBroadcasts,
    broadcastRecipients: newBroadcastRecipients
  }
}

export const broadcastsReducers = {
  ...makeReducers(BROADCASTS_GET, { transform: broadcastsTransform }),
  ...makeReducers(SINGLE_BROADCAST_GET, { transform: additiveBroadcastsTransform }),
  [BROADCASTS_CLEAR]: (state: State) => ({ ...state, broadcasts: getDefaultBroadcasts() })
}

export * from './broadcastContacts'
export * from './broadcastResources'
