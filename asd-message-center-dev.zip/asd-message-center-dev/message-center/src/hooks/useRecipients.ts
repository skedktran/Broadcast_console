import * as React from 'react'
import { useSelector } from 'react-redux'

import { Resource, Contact, State } from '../Store'

import { RecipientType } from '../Store/types'

export type Unified = {UID: string, Name: string, Avatar: string | null, Category: string | null}

export const useRecipients: (type: RecipientType) => [Unified[], string[]] = type => {
  const { nodes, selectedNodes, unify } = fields[type]
  // @ts-ignore
  const [recipients, selectedRecipients] = useSelector((state: State) => [state[nodes], state[selectedNodes]])
  const [unified, setUnified] = React.useState([])
  React.useEffect(() => setUnified(recipients.map(unify)), [recipients])
  return [unified, selectedRecipients]
}

type FieldConfig<T> = {
  nodes: string
  selectedNodes: string
  unify: (node: T) => Unified
}
export const fields: {
  [RecipientType.Resource]: FieldConfig<Resource>
  [RecipientType.Contact]: FieldConfig<Contact>
  } = {
    [RecipientType.Resource]: {
      nodes: 'resources',
      selectedNodes: 'selectedResources',
      unify: ({ Name, Avatar, UID, Category }) => ({ Name, Avatar, UID, Category })
    },
    [RecipientType.Contact]: {
      nodes: 'contacts',
      selectedNodes: 'selectedContacts',
      unify: ({ FullName, UID }) => ({ Name: FullName, Avatar: null, UID, Category: null })
    }
  }
