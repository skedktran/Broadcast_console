import React from 'react'
import {
  HashRouter as Router,
  Route,
  Switch,
  Redirect
} from 'react-router-dom'

import { RecipientType } from '../Store'
import { BroadcastPage } from '../pages/Broadcast'
import { BroadcastResourcesNewPage } from '../pages/BroadcastResourcesNew'
import { BroadcastSummary } from '../pages/BroadcastSummary'
import { BroadcastContactsNewPage } from '../pages/BroadcastContactsNew'


import { Navigation } from './Navigation'

import * as routes from '../pages/routes'

import { context, params, injectedRoutes } from '../Services/Services'

import './App.scss'

export class App extends React.PureComponent<{}, {}> {
  getInitialRoute = () => {
    let initialRoute = ''
    const incjetedToUse = Object.prototype.toString.call(context) === '[object Object]' ? injectedRoutes : context

    if (incjetedToUse) {
      initialRoute = `${initialRoute}/${Array.isArray(incjetedToUse) ? incjetedToUse.join('/') : incjetedToUse}`
    }
    if (params && Object.values(params).length) {
      initialRoute = `${initialRoute}/${Object.values(params).join('/')}`
    }
    return (initialRoute && initialRoute !== '/') ? initialRoute : routes.broadcastResourcesPath()
  }

  render() {
    return (
      <Router>
        <div className="app-wrapper">
          <Navigation />
          <Switch>
            <Redirect from={ routes.basePath() } exact to={ this.getInitialRoute() } />
            <Route exact path={ routes.broadcastResourcesPath() }>
              <BroadcastPage recipientType={ RecipientType.Resource } />
            </Route>
            <Route exact path={ routes.broadcastResourcesDetailsPath() }>
              <BroadcastPage recipientType={ RecipientType.Resource } />
            </Route>
            <Route exact path={ routes.broadcastResourcesSummaryPath() }>
              <BroadcastSummary recipientType={ RecipientType.Resource } />
            </Route>
            <Route exact path={ routes.broadcastResourcesNewPath({ config: true }) }>
              <BroadcastResourcesNewPage />
            </Route>
            <Route exact path={ routes.broadcastContactsPath() }>
              <BroadcastPage recipientType={ RecipientType.Contact } />
            </Route>
            <Route exact path={ routes.broadcastContactsDetailsPath() }>
              <BroadcastPage recipientType={ RecipientType.Contact } />
            </Route>
            <Route exact path={ routes.broadcastContactsNewPath({ config: true }) }>
              <BroadcastContactsNewPage />
            </Route>
            <Route exact path={ routes.broadcastContactsSummaryPath() }>
              <BroadcastSummary recipientType={ RecipientType.Contact } />
            </Route>
          </Switch>
        </div>
      </Router>
    )
  }
}
