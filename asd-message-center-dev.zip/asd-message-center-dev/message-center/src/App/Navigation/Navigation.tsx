import React, { useEffect } from 'react'
import { NavLink, useHistory, useRouteMatch } from 'react-router-dom'
import { IconNames, Icon } from '@skedulo/sked-ui'

import { navigation } from '../../Services/Services'

import * as routes from '../../pages/routes'

import './Navigation.scss'

export const Navigation: React.FC = () => {
  const history = useHistory()

  useEffect(() => {
    history.listen(({ pathname }) => {
      // '/a/b' => 'a/b' => ['a','b']
      const routes = pathname.substr(1).split('/')
      if (routes.length < 3) {
        navigation.setParentRoute(routes.join('/'))
      } else {
        // we cant set more than 2 routes to parent, so everything more is passed as parameter
        const [r1, r2, ...params] = routes
        navigation.setParentRoute(`${r1}/${r2}?${params.map((p, i) => `${i}=${p}`).join('&')}`)
      }
    })
  }, [])

  // looks like it just doesn't work without that
  navigation.registerRouteHandler(() => null)

  return (
    <nav className="navigation">
      <ul className="navigation__bar">
        {/*         <li>
          <NavigationIcon
            iconName="chat"
            matchPaths={ routes.broadcastContactsPath() }
            to={ routes.broadcastContactsPath() }
          />
        </li> */}
        <li>
          <NavigationIcon
            iconName="megaphone"
            matchPaths={ [routes.broadcastResourcesPath(), routes.broadcastContactsPath()] }
            to={ routes.broadcastResourcesPath() }
          />
        </li>
      </ul>
      <ul className="navigation__list">
        <li className="navigation__item-wrapper">
          <NavLink
            className="navigation__item"
            to={ routes.broadcastResourcesPath() }
            activeClassName="navigation__item--active"
          >Resources
          </NavLink>
        </li>
        <li className="navigation__item-wrapper">
          <NavLink
            className="navigation__item"
            to={ routes.broadcastContactsPath() }
            activeClassName="navigation__item--active"
          >Contacts
          </NavLink>
        </li>
      </ul>
    </nav>
  )
}

const NavigationIcon: React.FC<{
  iconName: IconNames
  matchPaths: string | string[]
  to: string
}> = ({ iconName, matchPaths, to }) => {
  const match = useRouteMatch(matchPaths)
  const history = useHistory()
  const classNames = `navigation__icon${match ? ' navigation__icon--active' : ''}`
  return (
    <div
      onClick={ () => history.push(to) }
      className={ classNames }
    >
      <Icon size={ 24 } name={ iconName } />
    </div>
  )
}
