const gulp  = require('gulp')
const run = require('child_process').exec
const del =  require('del')

function emitDeclarations(cb) {
  const task = run('tsc --emitDeclarationOnly --skipLibCheck --project src/temp')
  task.stdout.pipe(process.stdout)
  return task
}

function bundle(cb) {
  const task = run('webpack --config src/temp/webpack.config.js')
  task.stderr.pipe(process.stdout)
  return task
}

function clearDist(cb) {
  return del('src/temp/dist')
}

function clearDeclarations(cb) {
  return del(['src/temp/dist/**', '!src/temp/dist', '!src/temp/dist/index.js'])
}

function buildWatch(cb) {
  return gulp.watch([
    'src/temp/**/*.ts', 
    'src/temp/**/*.tsx',
    '!src/temp/dist/**',
    '!src/temp/**/*.test.tsx',
    '!src/temp/**/*.test.ts',
    '!src/temp/**/*.stories.tsx'
  ], gulp.parallel(gulp.series(clearDeclarations, emitDeclarations), bundle))
}

const build = gulp.series(clearDist, gulp.parallel(emitDeclarations, bundle))

exports.build = build 
exports.buildWatch = buildWatch
exports.clean = clearDist
exports.clearDeclarations = clearDeclarations
exports.bundle = bundle
exports.emitDeclarations = emitDeclarations