import * as React from 'react'

export const TestComponent = () => (<div className="sk-bg-grey sk-text-white">Test Component</div>)
