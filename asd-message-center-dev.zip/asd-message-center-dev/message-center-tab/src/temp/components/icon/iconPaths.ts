const arrowLeft = require('./icons/arrow-left.svg')
const arrowUp = require('./icons/arrow-up.svg')
const arrowDown = require('./icons/arrow-down.svg')
const chat = require('./icons/chat.svg')
const cardSize = require('./icons/card-size.svg')
const attributeFilled = require('./icons/attribute-filled.svg')
const plus = require('./icons/plus.svg')
const locked = require('./icons/locked.svg')
const map = require('./icons/map.svg')
const unlocked = require('./icons/unlocked.svg')
const attribute = require('./icons/attribute.svg')
const infoFill = require('./icons/info-fill.svg')
const recurring = require('./icons/recurring.svg')
const shift = require('./icons/shift.svg')
const chevronUp = require('./icons/chevron-up.svg')
const chevronDown = require('./icons/chevron-down.svg')
const chevronRight = require('./icons/chevron-right.svg')
const chevronLeft = require('./icons/chevron-left.svg')
const actions = require('./icons/actions.svg')
const notify = require('./icons/notify.svg')
const availability = require('./icons/availability.svg')
const tick = require('./icons/tick.svg')
const search = require('./icons/search.svg')
const settings = require('./icons/settings.svg')
const calendar = require('./icons/calendar.svg')
const calendarNavRight = require('./icons/calendar-nav-right.svg')
const calendarNavLeft = require('./icons/calendar-nav-left.svg')
const bookmark = require('./icons/bookmark.svg')
const optimise = require('./icons/optimise.svg')
const jobs = require('./icons/jobs.svg')
const optimiseFill = require('./icons/optimise-fill.svg')
const remove = require('./icons/remove.svg')
const filter = require('./icons/filter.svg')
const filterNew = require('./icons/filter-new.svg')
const zoomIn = require('./icons/zoom-in.svg')
const zoomOut = require('./icons/zoom-out.svg')
const logout = require('./icons/logout.svg')
const ellipsisVertical = require('./icons/ellipsis-vertical.svg')
const trash = require('./icons/trash.svg')
const shiftOvernight = require('./icons/shift-overnight.svg')
const minus = require('./icons/minus.svg')
const copy = require('./icons/copy.svg')
const resource = require('./icons/resource.svg')
const resourceRemove = require('./icons/resource-remove.svg')
const resourceBelow = require('./icons/resource-below.svg')
const resourceAdd = require('./icons/resource-add.svg')
const resourceAbove = require('./icons/resource-above.svg')
const phone = require('./icons/phone.svg')
const edit = require('./icons/edit.svg')
const dispatch = require('./icons/dispatch.svg')
const sms = require('./icons/sms.svg')
const today = require('./icons/today.svg')
const critical = require('./icons/critical.svg')
const cancel = require('./icons/cancel.svg')
const bell = require('./icons/bell.svg')
const bellAlert = require('./icons/bell-alert.svg')
const help = require('./icons/help.svg')
const openLink = require('./icons/open-link.svg')
const megaphone = require('./icons/megaphone.svg')
const scheduling = require('./icons/scheduling.svg')
const jobFields = require('./icons/job-fields.svg')
const attachments = require('./icons/attachments.svg')
const notes = require('./icons/notes.svg')
const tasks = require('./icons/tasks.svg')
const info = require('./icons/info.svg')
const contact = require('./icons/contact.svg')
const details = require('./icons/details.svg')
const time = require('./icons/time.svg')
const view = require('./icons/view.svg')
const unschedule = require('./icons/unschedule.svg')
const sortDescending = require('./icons/sort-descending.svg')
const sortAscending = require('./icons/sort-ascending.svg')
const push = require('./icons/push.svg')
const mapResource = require('./icons/map-resource.svg')
const upload = require('./icons/upload.svg')
const planeLanding = require('./icons/plane-landing.svg')
const planeTakeoff = require('./icons/plane-take-off.svg')
const planeLandingGround = require('./icons/plane-landing-with-ground.svg')
const urgent = require('./icons/urgent.svg')
const suggest = require('./icons/suggest.svg')
const upDown = require('./icons/up-down.svg')
const dateRange = require('./icons/date-range.svg')
const glasses = require('./icons/glasses.svg')
const reorder = require('./icons/reorder.svg')
const hide = require('./icons/hide.svg')
const location = require('./icons/location.svg')
const normal = require('./icons/normal.svg')
const bookingGrid = require('./icons/booking-grid.svg')
const warningFill = require('./icons/warning-fill.svg')
const warning = require('./icons/warning.svg')
const activity = require('./icons/activity.svg')
const dashboard = require('./icons/dashboard.svg')
const tickCircle = require('./icons/tick-circle.svg')
const salesforce = require('./icons/salesforce.svg')
const pin = require('./icons/pin.svg')
const restore = require('./icons/restore.svg')
const skeduloText = require('./icons/skedulo-text.svg')
const skedulo = require('./icons/skedulo.svg')
const swimlane = require('./icons/swimlane.svg')
const swimlaneVertical = require('./icons/swimlane-vertical.svg')
const exclamation = require('./icons/exclamation.svg')
const error = require('./icons/error.svg')
const checkmark = require('./icons/checkmark.svg')

export default {
  actions,
  activity,
  arrowLeft,
  arrowUp,
  arrowDown,
  attachments,
  attribute,
  attributeFilled,
  availability,
  bell,
  bellAlert,
  bookingGrid,
  bookmark,
  calendar,
  calendarNavRight,
  calendarNavLeft,
  cancel,
  cardSize,
  chat,
  checkmark,
  chevronUp,
  chevronDown,
  chevronLeft,
  chevronRight,
  contact,
  copy,
  critical,
  dashboard,
  dateRange,
  details,
  dispatch,
  edit,
  ellipsisVertical,
  error,
  exclamation,
  filter,
  filterNew,
  glasses,
  help,
  hide,
  info,
  infoFill,
  jobFields,
  jobs,
  location,
  locked,
  logout,
  map,
  mapResource,
  megaphone,
  minus,
  normal,
  notes,
  notify,
  openLink,
  optimise,
  optimiseFill,
  phone,
  pin,
  planeLanding,
  planeLandingGround,
  planeTakeoff,
  plus,
  push,
  recurring,
  remove,
  reorder,
  resource,
  resourceAbove,
  resourceAdd,
  resourceBelow,
  resourceRemove,
  restore,
  salesforce,
  scheduling,
  search,
  settings,
  shift,
  shiftOvernight,
  skedulo,
  skeduloText,
  sms,
  sortAscending,
  sortDescending,
  suggest,
  swimlane,
  swimlaneVertical,
  tasks,
  tick,
  tickCircle,
  time,
  today,
  trash,
  unlocked,
  unschedule,
  upDown,
  upload,
  urgent,
  view,
  warning,
  warningFill,
  zoomIn,
  zoomOut
}
