export const range = (length: number) => Array.from({ length }, (_, i) => i)
