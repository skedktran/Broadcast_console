import * as React from 'react'
import { BroadcastPage } from './Pages/Broadcast'
import { RecipientType } from './Store'

export class App extends React.PureComponent<{}, {}> {
  render() {
    return (
      <div>
        <BroadcastPage recipientType={ RecipientType.Resource } />
      </div>
    )
  }
}
