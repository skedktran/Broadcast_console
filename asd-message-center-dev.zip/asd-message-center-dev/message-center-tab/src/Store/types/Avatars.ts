export interface Avatars {
  [index: string]: string
}
