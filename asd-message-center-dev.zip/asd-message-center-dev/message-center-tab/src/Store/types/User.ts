export interface User {
  UID: string
}
