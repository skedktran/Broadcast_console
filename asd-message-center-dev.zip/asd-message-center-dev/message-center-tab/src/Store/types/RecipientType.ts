export enum RecipientType {
  Resource = 'Resource',
  Contact = 'Contact'
}
