import { IFilter } from '@skedulo/sked-ui/dist/components/filter-bar/interfaces'

import { Resource } from './Resource'
import { Contact } from './Contact'
import { Broadcast } from './Broadcast'
import { BroadcastRecipient } from './BroadcastRecipient'
import { Avatars } from './Avatars'
import { FilterBarFilterItem, FilterableObjectName } from '../filters/config'

export interface State {
  allResources: {
    [key: string]: Resource
  }
  resources: Resource[]

  allContacts: {
    [key: string]: Contact
  }
  contacts: Contact[]

  broadcasts: Broadcast[]
  broadcastRecipients: { [recipientId: string]: BroadcastRecipient }
  avatars: Avatars
  busyCnt: string[]
  filterOptions: {[key in FilterableObjectName]?: IFilter<FilterBarFilterItem>[]}

  selectedResources: string[]
  selectedContacts: string[]
}
