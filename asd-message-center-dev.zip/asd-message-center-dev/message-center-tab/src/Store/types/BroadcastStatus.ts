export enum BroadcastStatus {
  Sent = 'Sent',
  Error = 'Error'
}
