import { User } from './User'
import { NotificationMethod } from './NotificationMethod'

export interface Resource {
  UID: string
  Name: string
  User: User
  Avatar: string
  NotificationType: NotificationMethod
  MobilePhone: string
  Category: string
}
