import { RecipientType } from './RecipientType'
import { NotificationMethod } from './NotificationMethod'

export interface Broadcast {
  UID: string
  Broadcast: string
  NotificationMethod: NotificationMethod
  RecipientType: RecipientType
  Date: string
  Timestamp: string
  RecipientIds: string[]
  Sent: number
  NotSent: number
  TotalRecipients: number
}
