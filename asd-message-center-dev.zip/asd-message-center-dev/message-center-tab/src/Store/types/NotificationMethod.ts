export enum NotificationMethod {
  SMS = 'SMS',
  Push = 'Push',
  Preferred = 'PreferredNotificationMethod'
}
