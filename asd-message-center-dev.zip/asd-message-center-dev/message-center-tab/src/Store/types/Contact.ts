export interface Contact {
  UID: string
  FullName: string
  MobilePhone: string
}
