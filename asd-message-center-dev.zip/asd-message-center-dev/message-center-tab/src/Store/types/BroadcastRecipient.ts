import { BroadcastStatus } from "./BroadcastStatus";
import { NotificationMethod } from "./NotificationMethod";

export interface BroadcastRecipient {
  UID: string
  Date: string
  Phone: string
  Status: BroadcastStatus
  ContactId?: string
  ResourceId?: string
  BroadcastId: string
  Timestamp: string
  ErrorInformation: string
  NotificationMethod: NotificationMethod
}
