import { RecipientType, State } from './types'
import {
  makeActionCreator
} from '../common/utils/redux-helpers'


const CHANGE_RESOURCE_SELECTION = 'CHANGE_RESOURCE_SELECTION'
export const getDefaultSelectedResources: () => {selectedResources: string[]} = () => ({ selectedResources: [] })
export const setResourcesSelection = makeActionCreator(CHANGE_RESOURCE_SELECTION, null, 'selectedResources')

const CHANGE_CONTACT_SELECTION = 'CHANGE_CONTACT_SELECTION'
export const getDefaultSelectedContacts: () => {selectedContacts: string[]} = () => ({ selectedContacts: [] })
export const setContactsSelection = makeActionCreator(CHANGE_CONTACT_SELECTION, null, 'selectedContacts')

const CHANGE_SELECTION = 'CHANGE_SELECTION'
export const setSelection = makeActionCreator(CHANGE_SELECTION, null, ['selectionType', 'selection'])

export const newPageReducers = {
  [CHANGE_SELECTION]: (
    state: State,
    { selectionType, selection }: {selectionType: RecipientType, selection: string[]}
  ) => {
    const newSelection = selectionType === RecipientType.Resource
      ? { selectedResources: selection }
      : { selectedContacts: selection }
    return {
      ...state,
      ...newSelection
    }
  },
  [CHANGE_RESOURCE_SELECTION]: (
    state: State,
    { selectedResources }: { selectedResources: []}
  ) => {
    return {
      ...state,
      selectedResources
    }
  },
  [CHANGE_CONTACT_SELECTION]: (
    state: State,
    { selectedContacts }: { selectedContacts: []}
  ) => {
    return {
      ...state,
      selectedContacts
    }
  }
}
