import { Reducer } from 'redux'
import {
  makeReducer,
  DEF_RES_STATE
} from '../common/utils/redux-helpers'

import { State } from './types'

import {
  getDefaultResources,
  resourcesReducers
} from './reducerResources'

import {
  getDefaultContacts,
  contactsReducers
} from './reducerContacts'

import {
  getDefaultBroadcasts,
  getDefaultRecipients,
  broadcastsReducers
} from './reducerBroadcasts'

import {
  getDefaultAvatars,
  avatarsReducers
} from './reducerAvatars'

import {
  getDefaultFilters,
  filterReducers
} from './filters/reducerFilters'

import {
  getDefaultSelectedResources,
  getDefaultSelectedContacts,
  newPageReducers
} from './reducerNewPage'


const DEF_STATE: State = {
  ...DEF_RES_STATE,
  ...getDefaultFilters(),
  ...getDefaultSelectedResources(),
  ...getDefaultSelectedContacts(),
  ...getDefaultResources(),
  ...getDefaultContacts(),
  broadcasts: getDefaultBroadcasts(),
  broadcastRecipients: getDefaultRecipients(),
  avatars: getDefaultAvatars()
}

const reducer = makeReducer({
  ...resourcesReducers,
  ...contactsReducers,
  ...broadcastsReducers,
  ...avatarsReducers,
  ...filterReducers,
  ...newPageReducers
}, DEF_STATE) as Reducer

export default reducer
