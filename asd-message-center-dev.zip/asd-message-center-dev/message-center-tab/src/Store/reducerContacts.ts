import {
  makeActionsSet,
  makeReducers,
  makeAsyncActionCreatorSimp
} from '../common/utils/redux-helpers'

import * as Queries from './queries'
import { Services } from '../Services/Services'
import { State, Contact } from './types'

const CONTACTS_GET = makeActionsSet('CONTACTS_GET')

type ContactsHelper = Pick<State, 'contacts' | 'allContacts'>

export const getDefaultContacts = () => ({ contacts: [], allContacts: {} } as ContactsHelper)

export const getContacts = makeAsyncActionCreatorSimp(
  CONTACTS_GET, (variables: { filter?: string } = {}) => async () => {
    const resp = await Services.graphQL.fetch<{}>({
      query: Queries.ContactsQuery,
      variables
    })
    return resp
  }
)

const contactsTransform = ({ contacts }: {contacts: Contact[]}, state: State) => {
  const allContacts = contacts.reduce((acc, contact) => {
    acc[contact.UID] = { ...contact }
    return acc
  }, { ...state.allContacts })
  return {
    contacts,
    allContacts
  }
}

export const contactsReducers = {
  ...makeReducers(CONTACTS_GET, { transform: contactsTransform })
}
