import * as Mutations from '../mutations'
import { Services } from '../../Services/Services'
import {
  BroadcastStatus,
  NotificationMethod,
  RecipientType
} from '../types'

export interface NewBroadcast {
  sked_Broadcast: string
  sked_NotificationMethod: NotificationMethod
  sked_RecipientType: RecipientType
  sked_Date: string
  sked_Timestamp: string
  sked_Sent: number
  sked_NotSent: number
  sked_TotalRecipients: number
}
export interface NewBroadcastRecipient {
  sked_ContactId?: string
  sked_ResourceId?: string
  sked_BroadcastId: string
  sked_NotificationMethod: NotificationMethod
  sked_Phone: string
  sked_Status: BroadcastStatus
  sked_Date: string
  sked_Timestamp: string
  sked_ErrorInformation?: string
}

export interface BroadcastUpdate extends Partial<NewBroadcast> {
  UID: string
}

export interface BroadcastRecipientUpdate extends Partial<NewBroadcastRecipient> {
  UID: string
}

export interface SendingResult {
  status: BroadcastStatus
  notificationMethod?: NotificationMethod
  error?: object
}

export interface SendingResults {
  [recipientId: string]: SendingResult
}

const createBroadcast = async (broadcast: NewBroadcast) => {
  const { schema: { broadcastId } } = await Services.graphQL.mutate({
    query: Mutations.CreateBroadcast,
    variables: {
      createInput: broadcast
    }
  })

  return broadcastId
}

export const updateBroadcast = async (broadcast: BroadcastUpdate) => {
  const { schema: { broadcastId } } = await Services.graphQL.mutate({
    query: Mutations.UpdateBroadcast,
    variables: {
      updateInput: broadcast
    }
  })

  return broadcastId
}

const createBroadcastRecipients = async (recipients: NewBroadcastRecipient[]) => {
  const variables = recipients.reduce((acc, recipient, index) => ({
    ...acc,
    [`input${index}`]: recipient
  }), {})

  const { schema } = await Services.graphQL.mutate({
    variables,
    query: Mutations.CreateBroadcastRecipients(recipients.length)
  })

  return schema
}

export const updateBroadcastRecipients = async (recipients: BroadcastRecipientUpdate[]) => {
  const variables = recipients.reduce((acc, recipient, index) => ({
    ...acc,
    [`input${index}`]: recipient
  }), {})

  const { schema } = await Services.graphQL.mutate({
    variables,
    query: Mutations.UpdateBroadcastRecipients(recipients.length)
  })

  return schema
}

export const createBroadcastAndRecipients = async (broadcast: NewBroadcast, recipients: NewBroadcastRecipient[]) => {
  const broadcastId = await createBroadcast(broadcast)
  await createBroadcastRecipients(recipients.map(recipient => ({
    ...recipient,
    sked_BroadcastId: broadcastId
  })))
  return broadcastId
}
