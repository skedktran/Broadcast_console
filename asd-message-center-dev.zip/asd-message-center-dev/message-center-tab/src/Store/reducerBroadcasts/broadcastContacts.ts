import { Dispatch } from 'redux'
import { format } from 'date-fns'
import PhoneNumber from 'awesome-phonenumber'
import {
  makeActionsSet,
  makeAsyncActionCreatorSimp
} from '../../common/utils/redux-helpers'

import { Services } from '../../Services/Services'
import {
  BroadcastStatus,
  NotificationMethod,
  RecipientType,
  State
} from '../types'
import {
  SendingResults,
  createBroadcastAndRecipients,
  updateBroadcast,
  updateBroadcastRecipients
} from './common'

const BROADCAST_CONTACT = makeActionsSet('BROADCAST_CONTACT')
const BROADCAST_CONTACTS = makeActionsSet('BROADCAST_CONTACTS')
const REBROADCAST_CONTACT = makeActionsSet('REBROADCAST_CONTACT')

const sendMessageToContacts = async (message: string, contacts: {
  contactId: string
  phoneNumber: string
  countryCode: string
}[]) => {
  const timestamp = `${Date.now()}`
  const sendDate = format(new Date(), 'yyyy-MM-dd')

  const results = await Promise.all(contacts.map(contact => Services.metadata._apiService.post(
    '/notifications/sms',
    {
      message,
      countryCode: contact.countryCode,
      phoneNumber: contact.phoneNumber
    }
  )
    .then(() => ({ status: BroadcastStatus.Sent, error: null }))
    .catch(error => ({ status: BroadcastStatus.Error, error }))))

  const sendingResult = {} as SendingResults
  contacts.forEach((contact, i) => {
    sendingResult[contact.contactId] = {
      status: results[i].status,
      error: results[i].error?.message
    }
  })

  return { sendingResult, timestamp, sendDate }
}

export const broadcastContact = makeAsyncActionCreatorSimp(
  BROADCAST_CONTACT, (options: {
    contactId: string
    message: string
  }) => async (dispatch: Dispatch, getState: () => State) => {
    const contact = getState().contacts.find(contact => contact.UID === options.contactId)
    const countryCode = new PhoneNumber(contact.MobilePhone).getRegionCode()
    const { sendingResult, timestamp, sendDate } = await sendMessageToContacts(
      options.message,
      [{
        contactId: contact.UID,
        phoneNumber: contact.MobilePhone,
        countryCode
      }]
    )
    const sendingStatus = sendingResult[contact.UID].status
    const sendingError = sendingStatus === BroadcastStatus.Error
      ? JSON.stringify({ [timestamp]: sendingResult.error })
      : null

    createBroadcastAndRecipients(
      {
        sked_Broadcast: options.message,
        sked_NotificationMethod: NotificationMethod.SMS,
        sked_RecipientType: RecipientType.Contact,
        sked_Date: sendDate,
        sked_Timestamp: timestamp,
        sked_Sent: sendingStatus === BroadcastStatus.Sent ? 1 : 0,
        sked_NotSent: sendingStatus === BroadcastStatus.Error ? 1 : 0,
        sked_TotalRecipients: 1
      },
      [
        {
          sked_BroadcastId: null,
          sked_ContactId: options.contactId,
          sked_ResourceId: null,
          sked_NotificationMethod: NotificationMethod.SMS,
          sked_Phone: contact.MobilePhone,
          sked_Status: sendingStatus,
          sked_Date: sendDate,
          sked_Timestamp: timestamp,
          sked_ErrorInformation: sendingError
        }
      ]
    )
  }
)

export const broadcastContacts = makeAsyncActionCreatorSimp(
  BROADCAST_CONTACTS, (
    options: {
      message: string
      contactIds: string[]
    },
    callback?: (UID: string) => void
  ) => async (dispatch: Dispatch, getState: () => State) => {
    const contacts = getState().contacts.filter(contact => options.contactIds.includes(contact.UID))

    const { sendingResult, timestamp, sendDate } = await sendMessageToContacts(
      options.message,
      contacts.map(contact => {
        const phoneNumber = new PhoneNumber(contact.MobilePhone)
        return {
          contactId: contact.UID,
          phoneNumber: phoneNumber.getNumber(),
          countryCode: phoneNumber.getRegionCode()
        }
      })
    )

    const sked_Sent = Object.values(sendingResult)
      .filter(contactResult => contactResult.status === BroadcastStatus.Sent)
      .length
    const sked_TotalRecipients = Object.keys(sendingResult).length
    const sked_NotSent = sked_TotalRecipients - sked_Sent

    const broadcastUID = await createBroadcastAndRecipients(
      {
        sked_Broadcast: options.message,
        sked_NotificationMethod: NotificationMethod.SMS,
        sked_RecipientType: RecipientType.Contact,
        sked_Date: sendDate,
        sked_Timestamp: timestamp,
        sked_Sent,
        sked_NotSent,
        sked_TotalRecipients
      },
      contacts.map(contact => {
        const sendingStatus = sendingResult[contact.UID].status
        const sendingError = sendingStatus === BroadcastStatus.Error
          ? JSON.stringify({ [timestamp]: sendingResult[contact.UID].error })
          : null

        return {
          sked_BroadcastId: null,
          sked_ContactId: contact.UID,
          sked_ResourceId: null,
          sked_NotificationMethod: NotificationMethod.SMS,
          sked_Phone: contact.MobilePhone,
          sked_Status: sendingStatus,
          sked_Date: sendDate,
          sked_Timestamp: timestamp,
          sked_ErrorInformation: sendingError
        }
      })
    )
    if (callback) {
      callback(broadcastUID)
    }
  }
)

export const rebroadcastContacts = makeAsyncActionCreatorSimp(
  REBROADCAST_CONTACT, (
    broadcastId: string,
    recipientIds: string[],
    callback?: () => void
  ) => async (dispatch: Dispatch, getState: () => State) => {
    const state = getState()
    const broadcast = state.broadcasts.find(b => b.UID === broadcastId)
    if (!broadcast) return

    const recipients = recipientIds
      .map(recipientId => {
        const recipient = state.broadcastRecipients[recipientId]
        return (recipient?.Status === BroadcastStatus.Error)
          ? recipient
          : null
      })
      .filter(recipient => !!recipient)

    if (!recipients.length) return

    const { sendingResult, timestamp, sendDate } = await sendMessageToContacts(
      broadcast.Broadcast,
      recipients.map(recipient => {
        const contact = state.contacts.find(({ UID }) => UID === recipient.ContactId)
        const phoneNumber = new PhoneNumber(contact?.MobilePhone)
        return {
          contactId: recipient.ContactId,
          phoneNumber: phoneNumber.getNumber(),
          countryCode: phoneNumber.getRegionCode()
        }
      })
    )

    const newBroadcastsSentCount = (
      broadcast.Sent +
      Object.values(sendingResult)
        .filter(result => result.status === BroadcastStatus.Sent)
        .length
    )
    await updateBroadcast({
      UID: broadcast.UID,
      sked_Sent: newBroadcastsSentCount,
      sked_NotSent: broadcast.TotalRecipients - newBroadcastsSentCount
    })

    await updateBroadcastRecipients(recipients.map(recipient => {
      let previousSendingError = null
      try {
        previousSendingError = JSON.parse(recipient.ErrorInformation)
      } catch (e) {
        previousSendingError = null
      }

      const sendingStatus = sendingResult[recipient.ContactId].status
      const sendingError = sendingStatus === BroadcastStatus.Error
        ? JSON.stringify({
          ...previousSendingError,
          [timestamp]: sendingResult[recipient.ContactId].error
        })
        : recipient.ErrorInformation

      return ({
        UID: recipient.UID,
        sked_Timestamp: timestamp,
        sked_Date: sendDate,
        sked_Status: sendingResult[recipient.ContactId].status,
        sked_ErrorInformation: sendingError
      })
    }))

    if (callback) {
      callback()
    }
  }
)
