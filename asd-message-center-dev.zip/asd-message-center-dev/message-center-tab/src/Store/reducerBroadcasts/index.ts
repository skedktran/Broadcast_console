import { Dispatch } from 'redux'
import {
  makeActionsSet,
  makeReducers,
  makeAsyncActionCreatorSimp,
  makeActionCreator
} from '../../common/utils/redux-helpers'

import * as Queries from '../queries'
import { Services } from '../../Services/Services'
import {
  Broadcast,
  BroadcastRecipient,
  RecipientType,
  State
} from '../types'
import { getResources } from '../reducerResources'
import { getContacts } from '../reducerContacts'

const BROADCASTS_GET = makeActionsSet('BROADCASTS_GET')
const BROADCASTS_CLEAR = 'BROADCASTS_CLEAR'
const SINGLE_BROADCAST_GET = makeActionsSet('SINGLE_BROADCAST_GET')

export const getDefaultBroadcasts = () => [] as Broadcast[]
export const getDefaultRecipients = () => ({} as { [recipientId: string]: BroadcastRecipient })

export const clearBroadcasts = makeActionCreator(BROADCASTS_CLEAR)

export const getBroadcasts = makeAsyncActionCreatorSimp(
  BROADCASTS_GET, (recipientType?: RecipientType, start?: Date, end?: Date, resourceId?: string) => async (dispatch: Dispatch) => {
    dispatch(clearBroadcasts())

    const broadcastFilters = [
      recipientType ? `sked_RecipientType == "${recipientType}"` : null,
      start ? `sked_Timestamp > "${start.getTime()}"` : null,
      end ? `sked_Timestamp < "${end.getTime()}"` : null,
      resourceId ? `UID IN (SELECT sked_BroadcastId FROM sked_BroadcastRecipients WHERE (sked_ResourceId IN ["${resourceId}"]))` : null
    ].filter(filter => filter !== null)

    const resp = await Services.graphQL.fetch<{ broadcasts: Broadcast[], broadcastRecipients: BroadcastRecipient[] }>({
      query: Queries.BroadcastsQuery,
      variables: {
        broadcastsFilter: broadcastFilters.length ? broadcastFilters.join(' AND ') : null,
        recipientsFilter: recipientType ? `sked_Broadcast.sked_RecipientType == "${recipientType}"` : null
      }
    })
    return resp
  }
)

export const getBroadcastById = makeAsyncActionCreatorSimp(
  SINGLE_BROADCAST_GET, (id: string) => async (dispatch: Dispatch) => {
    const resp = await Services.graphQL.fetch<{ broadcast: Broadcast, broadcastRecipients: BroadcastRecipient[] }>({
      query: Queries.SingleBroadcastQuery,
      variables: {
        id,
        recipientsFilter: `sked_BroadcastId == "${id}"`
      }
    })

    if (resp.broadcast.RecipientType === RecipientType.Resource) {
      const resourceIds = resp.broadcastRecipients
        .map(recipient => recipient.ResourceId)
        .filter(id => !!id)
      dispatch(getResources({ filter: `UID IN [${resourceIds.map(id => `"${id}"`).join(', ')}]` }))
    } else if (resp.broadcast.RecipientType === RecipientType.Contact) {
      const contactIds = resp.broadcastRecipients
        .map(recipient => recipient.ContactId)
        .filter(id => !!id)
      dispatch(getContacts({ filter: `UID IN [${contactIds.map(id => `"${id}"`).join(', ')}]` }))
    }

    return {
      broadcasts: [resp.broadcast],
      broadcastRecipients: resp.broadcastRecipients
    }
  }
)

const transformToIndexedDataStructures = (result: {
  broadcasts: Broadcast[]
  broadcastRecipients: BroadcastRecipient[]
}) => {
  const broadcasts = result.broadcasts.reduce((acc, broadcast) => ({
    ...acc,
    [broadcast.UID]: {
      ...broadcast,
      RecipientIds: []
    }
  }), {} as { [broadcastId: string]: Broadcast })

  result.broadcastRecipients.forEach(recipient => {
    const broadcast = broadcasts[recipient.BroadcastId]
    if (broadcast) {
      broadcast.RecipientIds.push(recipient.UID)
    }
  })

  const broadcastRecipients = result.broadcastRecipients.reduce((acc, recipient) => ({
    ...acc,
    [recipient.UID]: recipient
  }), {} as { [recipientId: string]: BroadcastRecipient })

  return {
    broadcasts,
    broadcastRecipients
  }
}

const broadcastsTransform = (result: {
  broadcasts: Broadcast[]
  broadcastRecipients: BroadcastRecipient[]
}) => {
  const { broadcasts, broadcastRecipients } = transformToIndexedDataStructures(result)

  return {
    broadcasts: Object.values(broadcasts),
    broadcastRecipients
  }
}

const additiveBroadcastsTransform = (
  result: {
    broadcasts: Broadcast[]
    broadcastRecipients: BroadcastRecipient[]
  },
  state: State
) => {
  const { broadcasts, broadcastRecipients } = broadcastsTransform(result)

  const newBroadcasts = [...state.broadcasts]

  broadcasts.forEach(broadcast => {
    const index = newBroadcasts.findIndex(({ UID }) => broadcast.UID === UID)
    if (index === -1) {
      newBroadcasts.push(broadcast)
    } else {
      newBroadcasts[index] = broadcast
    }
  })
  newBroadcasts.sort((broadcast1, broadcast2) => (broadcast1.Timestamp < broadcast2.Timestamp) ? 1 : -1)

  const newBroadcastRecipients = {
    ...state.broadcastRecipients,
    ...broadcastRecipients
  }

  return {
    broadcasts: newBroadcasts,
    broadcastRecipients: newBroadcastRecipients
  }
}

export const broadcastsReducers = {
  ...makeReducers(BROADCASTS_GET, { transform: broadcastsTransform }),
  ...makeReducers(SINGLE_BROADCAST_GET, { transform: additiveBroadcastsTransform }),
  [BROADCASTS_CLEAR]: (state: State) => ({ ...state, broadcasts: getDefaultBroadcasts() })
}

export * from './broadcastContacts'
export * from './broadcastResources'
