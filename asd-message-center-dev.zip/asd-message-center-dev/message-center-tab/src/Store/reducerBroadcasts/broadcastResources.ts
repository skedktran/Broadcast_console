import { Dispatch } from 'redux'
import { format } from 'date-fns'
import {
  makeActionsSet,
  makeAsyncActionCreatorSimp
} from '../../common/utils/redux-helpers'

import { Services } from '../../Services/Services'
import {
  BroadcastStatus,
  NotificationMethod,
  RecipientType,
  State
} from '../types'
import {
  SendingResults,
  createBroadcastAndRecipients,
  updateBroadcast,
  updateBroadcastRecipients
} from './common'

const BROADCAST_RESOURCE = makeActionsSet('BROADCAST_RESOURCE')
const BROADCAST_RESOURCES = makeActionsSet('BROADCAST_RESOURCES')
const REBROADCAST_RESOURCES = makeActionsSet('REBROADCAST_RESOURCES')

const sendBroadcastToResources = async (message: string, resources: {
  resourceId: string
  notificationMethod: NotificationMethod
}[]) => {
  const timestamp = `${Date.now()}`
  const sendDate = format(new Date(), 'yyyy-MM-dd')

  const results = await Promise.all(resources.map(resource => Services.metadata._apiService.post(
    '/notifications/oneoff',
    {
      resourceId: resource.resourceId,
      message,
      protocol: resource.notificationMethod === NotificationMethod.SMS ? 'sms' : 'push'
    }
  )
    .then(() => ({ status: BroadcastStatus.Sent, error: null }))
    .catch(error => ({ status: BroadcastStatus.Error, error }))))

  const sendingResult = {} as SendingResults
  resources.forEach((resource, i) => {
    sendingResult[resource.resourceId] = {
      status: results[i].status,
      error: results[i].error?.message,
      notificationMethod: resource.notificationMethod
    }
  })

  return { sendingResult, timestamp, sendDate }
}

export const broadcastResource = makeAsyncActionCreatorSimp(
  BROADCAST_RESOURCE, (options: {
    resourceId: string
    notificationMethod: NotificationMethod
    message: string
  }) => async (dispatch: Dispatch, getState: () => State) => {
    const resource = getState().resources.find(resource => resource.UID === options.resourceId)
    const resourceNotificationMethod = options.notificationMethod === NotificationMethod.Preferred
      ? resource.NotificationType
      : options.notificationMethod

    const { sendingResult, timestamp, sendDate } = await sendBroadcastToResources(options.message, [{
      resourceId: resource.UID,
      notificationMethod: resourceNotificationMethod
    }])
    const sendingStatus = sendingResult[resource.UID].status
    const sendingError = sendingStatus === BroadcastStatus.Error
      ? JSON.stringify({ [timestamp]: sendingResult[resource.UID].error })
      : null

    createBroadcastAndRecipients(
      {
        sked_Broadcast: options.message,
        sked_NotificationMethod: options.notificationMethod,
        sked_RecipientType: RecipientType.Resource,
        sked_Date: sendDate,
        sked_Timestamp: timestamp,
        sked_Sent: sendingStatus === BroadcastStatus.Sent ? 1 : 0,
        sked_NotSent: sendingStatus === BroadcastStatus.Error ? 1 : 0,
        sked_TotalRecipients: 1
      },
      [{
        sked_BroadcastId: null,
        sked_ContactId: null,
        sked_ResourceId: options.resourceId,
        sked_NotificationMethod: resourceNotificationMethod,
        sked_Phone: resourceNotificationMethod === NotificationMethod.SMS ? resource.MobilePhone : null,
        sked_Status: sendingStatus,
        sked_Date: sendDate,
        sked_Timestamp: timestamp,
        sked_ErrorInformation: sendingError
      }]
    )
  }
)

export const broadcastResources = makeAsyncActionCreatorSimp(
  BROADCAST_RESOURCES, (options: {
    message: string
    resourceIds: string[]
    notificationMethod: NotificationMethod
    secondaryNotificationMethod?: NotificationMethod.Push | NotificationMethod.SMS
  }, callback?: (UID: string) => void) => async (dispatch: Dispatch, getState: () => State) => {
    const resources = getState().resources.filter(resource => options.resourceIds.includes(resource.UID))

    const { sendingResult, timestamp, sendDate } = await sendBroadcastToResources(
      options.message,
      resources.map(resource => ({
        resourceId: resource.UID,
        notificationMethod: options.notificationMethod === NotificationMethod.Preferred
          ? (resource.NotificationType || options.secondaryNotificationMethod)
          : options.notificationMethod
      }))
    )

    const sked_Sent = Object.values(sendingResult)
      .filter(resourceResult => resourceResult.status === BroadcastStatus.Sent)
      .length
    const sked_TotalRecipients = Object.keys(sendingResult).length
    const sked_NotSent = sked_TotalRecipients - sked_Sent

    const broadcastUID = await createBroadcastAndRecipients(
      {
        sked_Broadcast: options.message,
        sked_NotificationMethod: options.notificationMethod,
        sked_RecipientType: RecipientType.Resource,
        sked_Date: sendDate,
        sked_Timestamp: timestamp,
        sked_Sent,
        sked_NotSent,
        sked_TotalRecipients
      },
      resources.map(resource => {
        const resourceNotificationMethod = sendingResult[resource.UID].notificationMethod
        const sendingStatus = sendingResult[resource.UID].status
        const sendingError = sendingStatus === BroadcastStatus.Error
          ? JSON.stringify({ [timestamp]: sendingResult[resource.UID].error })
          : null

        return {
          sked_BroadcastId: null,
          sked_ContactId: null,
          sked_ResourceId: resource.UID,
          sked_NotificationMethod: resourceNotificationMethod,
          sked_Phone: resourceNotificationMethod === NotificationMethod.SMS ? resource.MobilePhone : null,
          sked_Status: sendingStatus,
          sked_Date: sendDate,
          sked_Timestamp: timestamp,
          sked_ErrorInformation: sendingError
        }
      })
    )
    if (callback) {
      callback(broadcastUID)
    }
  }
)

export const rebroadcastResources = makeAsyncActionCreatorSimp(
  REBROADCAST_RESOURCES, (
    broadcastId: string,
    recipientIds: string[],
    recipientNotificationMethods?: { [recipientId: string]: NotificationMethod },
    callback?: () => void
  ) => async (dispatch: Dispatch, getState: () => State) => {
    const state = getState()
    const broadcast = state.broadcasts.find(b => b.UID === broadcastId)
    if (!broadcast) return

    const recipients = recipientIds
      .map(recipientId => {
        const recipient = state.broadcastRecipients[recipientId]
        return (recipient?.Status === BroadcastStatus.Error)
          ? recipient
          : null
      })
      .filter(recipient => !!recipient)

    if (!recipients.length) return

    const { sendingResult, timestamp, sendDate } = await sendBroadcastToResources(
      broadcast.Broadcast,
      recipients.map(recipient => ({
        resourceId: recipient.ResourceId,
        notificationMethod: recipientNotificationMethods?.[recipient.UID] || recipient.NotificationMethod
      }))
    )

    const newBroadcastsSentCount = (
      broadcast.Sent +
      Object.values(sendingResult)
        .filter(result => result.status === BroadcastStatus.Sent)
        .length
    )
    await updateBroadcast({
      UID: broadcast.UID,
      sked_Sent: newBroadcastsSentCount,
      sked_NotSent: broadcast.TotalRecipients - newBroadcastsSentCount
    })

    await updateBroadcastRecipients(recipients.map(recipient => {
      let previousSendingError = null
      try {
        previousSendingError = JSON.parse(recipient.ErrorInformation)
      } catch (e) {
        previousSendingError = null
      }

      const sendingStatus = sendingResult[recipient.ResourceId].status
      const sendingError = sendingStatus === BroadcastStatus.Error
        ? JSON.stringify({
          ...previousSendingError,
          [timestamp]: sendingResult[recipient.ResourceId].error
        })
        : recipient.ErrorInformation

      return ({
        UID: recipient.UID,
        sked_Timestamp: timestamp,
        sked_Date: sendDate,
        sked_Status: sendingResult[recipient.ResourceId].status,
        sked_ErrorInformation: sendingError
      })
    }))

    if (callback) {
      callback()
    }
  }
)
