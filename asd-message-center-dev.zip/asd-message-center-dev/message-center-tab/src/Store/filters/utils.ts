import { IFilter } from '@skedulo/sked-ui/dist/components/filter-bar/interfaces'
import { Services } from '../../Services/Services'
import { FilterBarFilterItem, FiltersConfigOption, FilterType } from './config'

// const fields = JSON.parse(window.localStorage.customFields)
// new Set(Object.keys(fields).map(k => fields[k]).map(({fields: f}) => f.map(({fieldType}) => fieldType)).flat())
export type CustomFieldType = 'id'
                            | 'datetime'
                            | 'reference'
                            | 'date'
                            | 'picklist'
                            | 'string'
                            | 'textarea'
                            | 'time'
                            | 'decimal'
                            | 'multipicklist'
                            | 'boolean'
export interface FieldVocabulary {
  value: string
  label: string
  active: boolean
  defaultValue: boolean
  controllingField: unknown
  validFor: unknown[]
}
export interface FieldVocabularyInfo {
  schemaName: string
  fieldName: string
  vocabulary: FieldVocabulary[]
  fieldType: CustomFieldType
}
/**
 * eg.
 * @param schemaName Resource
 * @param fieldName Category
 * returns field vocabulary
 * used for custom fields of type 'picklist' and 'multipicklist'
 * and
 * predefined fields of 'picklist' and 'multipicklist' type (eg. Category)
 */
export const getFieldVocabulary = async (schemaName: string, fieldName: string, fieldType?: CustomFieldType) => {
  const vocabulary = await Services.metadata._apiService.get<FieldVocabulary[]>(`custom/vocabulary/${schemaName}/${fieldName}`)
  return {
    schemaName,
    fieldName,
    vocabulary,
    fieldType
  } as FieldVocabularyInfo
}

export const getSchemaVocabularies = async (schemaNames: string[]) => {
  return Services.metadata._apiService.get<Record<string, Record<string, FieldVocabulary[]>>>('custom/vocabularies', { names: schemaNames.join(',') })
}

/**
 * @param queryName query name for specific object eg. 'tags' for 'Tags'
 */
export const createSingleFilterQuery = (queryName: string, labelField = 'Name', keyField = 'UID') => (
  `${queryName}{
    edges {
      node {
        Name: ${labelField}
        UID: ${keyField}
      }
    }
  }`
)

export interface CustomObject {
  fields: CustomField[]
  isStandard: boolean
  label: string
  mapping: string
  name: string
}

export interface CustomField {
  [key: string]: unknown
  schemaName: string
  name: string
  label: string
  fieldType: CustomFieldType
}

export interface LocalStorageCustomFields {[key: string]: CustomObject}

export const getCustomFields = () => JSON.parse(window.localStorage.customFields) as LocalStorageCustomFields

export const getCustomFieldFilter = (objectName: string): FiltersConfigOption[] => {
  const customFields = getCustomFields()
  const objectCustomField = customFields[objectName]
  // if there are no key in localstorage, don't need to call additional request
  if (!objectCustomField) {
    return []
  }
  const {
    fields: objectFields
  } = objectCustomField

  return objectFields.filter(({ fieldType }) => fieldType === 'picklist' || fieldType === 'multipicklist')
    .map(({ name, label, fieldType }) => ({
      type: FilterType.vocabulary,
      name,
      label,
      inputType: 'checkbox',
      filterString: (vars: string) => `${name} IN [${vars}]`,
      schemaName: objectName,
      fieldType
    }))
}
/**
 *
 * @param objectName object in window.localStorage.customFields eg. Resources
 */
export const customFieldsFilters = async (objectName: string): Promise<IFilter<FilterBarFilterItem>[]> => {
  const customFields = getCustomFields()
  const objectCustomField = customFields[objectName]
  // if there are no key in localstorage, don't need to call additional request
  if (!objectCustomField) {
    return []
  }

  const {
    fields: objectFields = []
  } = objectCustomField
  const filtersPromises: Promise<FieldVocabularyInfo>[] = []

  objectFields.forEach(({ schemaName, name, fieldType }) => {
    if (fieldType === 'picklist' || fieldType === 'multipicklist') {
      filtersPromises.push(getFieldVocabulary(schemaName, name, fieldType))
    }
  })

  const filters = await Promise.all(filtersPromises)

  return filters.map(({ schemaName, fieldName, vocabulary, fieldType }) => ({
    name: fieldName,
    id: `${schemaName}-${fieldName}`,
    items: filterOptionsFromVocabulary[fieldType](vocabulary, fieldType),
    inputType: 'checkbox',
    selectedIds: []
  }))
}

export const defaultVocabularyOptionsGenerator = (fields: FieldVocabulary[], fieldType?: CustomFieldType) => fields.reduce<FilterBarFilterItem[]>(
  (acc, { active, value, label }) => active ? [...acc, { id: value, name: label, fieldType }] : acc,
  []
)

export const filterOptionsFromVocabulary: {[key in CustomFieldType]?: (field: FieldVocabulary[], fieldType: CustomFieldType) => FilterBarFilterItem[]} = {
  picklist: defaultVocabularyOptionsGenerator,
  multipicklist: defaultVocabularyOptionsGenerator
}

export const customFieldFilterQuery: {[key in CustomFieldType]?: (values: string[], name: string) => string} = {
  picklist: (values, name) => `${name} IN ["${values.join('","')}"]`,
  multipicklist: (values, name) => `(${values.map(singleMultiPickFilterQuery(name)).join(' OR ')})`
}

const singleMultiPickFilterQuery = (name: string) => (value: string) => `${name} INCLUDES "${value}"`
