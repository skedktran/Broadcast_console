import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import { IAppliedFilter } from '@skedulo/sked-ui'
import { State } from '..'
import { getFilterOptions, FILTER_OPTIONS_GET } from './reducerFilters'
import { filtersConfig, FilterableObjectName, FilterBarFilterItem } from './config'
import { customFieldFilterQuery } from './utils'

export const useFilters = (filterName: FilterableObjectName) => {
  const { filters: schemaFilters, baseFilter, operator } = filtersConfig[filterName]
  const dispatch = useDispatch()
  const requestInProgress = useSelector((state: State) => state.busyCnt)
  const [filterString, setFilterString] = useState(baseFilter)
  const filterOptions = useSelector((state: State) => state.filterOptions[filterName])

  if (!filterOptions && !requestInProgress.includes(FILTER_OPTIONS_GET.NAME)) {
    dispatch(getFilterOptions(filterName))
  }

  const onChange = (selectedFilters: IAppliedFilter<FilterBarFilterItem>[]) => {
    const queryFilter = selectedFilters.map(
      ({ name: filterName, id: filterId, selectedItems }) => {
        const theConfig = schemaFilters.find(({ name }) => name === filterId)
        if (theConfig) {
          const values = `"${selectedItems.map(({ id }) => id).join('","')}"`
          return theConfig.filterString(values)
        }

        const fieldType = selectedItems[0].fieldType

        return customFieldFilterQuery[fieldType](selectedItems.map(({ id }) => id), filterName)
      }
    )
      .filter(v => !!v)
      .join(` ${operator} `)

    setFilterString(
      queryFilter ? `${baseFilter ? `${baseFilter} AND ` : ''}${queryFilter}` : baseFilter
    )
  }


  return { filterOptions, onChange, filterString }
}
