import { CustomFieldType } from './utils'

export type FilterableObjectName = 'Resources' | 'Contacts'

export enum FilterOperator {
  AND = 'AND',
  OR = 'OR'
}

export enum FilterType {
  baseObject,
  vocabulary,
  custom
}

export declare type FilterInputType = 'checkbox' | 'radio'

export type FilterConfigInstance = {
  operator: FilterOperator
  customFields: boolean
  baseFilter?: string
  filters: FiltersConfigOption[]
}

export type IFiltersConfig = {
  [key in FilterableObjectName]: FilterConfigInstance
}

export interface FilterBarFilterItem {
  id: string
  name: string
  fieldType?: CustomFieldType
}

export interface FiltersConfigOption {
  type: FilterType
  name: string
  label: string
  labelField?: string
  keyField?: string
  fieldType?: CustomFieldType
  inputType: FilterInputType
  filterString: (filterVariables: string) => string

  schemaName?: string
}

export const filtersConfig: IFiltersConfig = {
  Resources: {
    operator: FilterOperator.AND,
    customFields: true,
    baseFilter: "IsActive == true AND ResourceType == 'Person'",
    filters: [
      {
        type: FilterType.baseObject,
        name: 'tags',
        label: 'Tags',
        labelField: 'Name',
        keyField: 'UID',
        inputType: 'checkbox',
        filterString: (vars: string) => `(UID IN (SELECT ResourceId FROM ResourceTags WHERE (TagId IN [${vars}])))`
      },
      {
        type: FilterType.baseObject,
        name: 'regions',
        label: 'Region',
        labelField: 'Name',
        keyField: 'UID',
        inputType: 'checkbox',
        filterString: (vars: string) => `PrimaryRegionId IN [${vars}]`
      },
      {
        type: FilterType.vocabulary,
        name: 'Category',
        label: 'Resource Category',
        inputType: 'checkbox',
        schemaName: 'Resources',
        filterString: (vars: string) => `Category IN [${vars}]`
      }
    ]
  },
  Contacts: {
    operator: FilterOperator.AND,
    customFields: true,
    filters: [
      {
        type: FilterType.baseObject,
        name: 'regions',
        label: 'Region',
        labelField: 'Name',
        keyField: 'UID',
        inputType: 'checkbox',
        filterString: (vars: string) => `RegionId IN [${vars}]`
      },
      {
        type: FilterType.baseObject,
        name: 'tags',
        label: 'Tags',
        labelField: 'Name',
        keyField: 'UID',
        inputType: 'checkbox',
        filterString: (vars: string) => `(UID IN (SELECT ContactId FROM ContactTags WHERE (TagId IN [${vars}])))`
      }
    ]
  }
}
