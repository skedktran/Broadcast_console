import { IFilter } from '@skedulo/sked-ui/dist/components/filter-bar/interfaces'
import uniq from 'lodash/fp/uniq'
import {
  makeActionsSet,
  makeReducers,
  makeAsyncActionCreatorSimp
} from '../../common/utils/redux-helpers'

import {
  // getFieldVocabulary,
  createSingleFilterQuery,
  // customFieldsFilters,
  defaultVocabularyOptionsGenerator,
  getCustomFieldFilter,
  getSchemaVocabularies
} from './utils'

import { Services } from '../../Services/Services'
import { State } from '../types'

import { filtersConfig, FilterType, FilterableObjectName, FilterBarFilterItem } from './config'


export const FILTER_OPTIONS_GET = makeActionsSet('FILTER_OPTIONS_GET') as {NAME: string}

export const getDefaultFilters = () => ({
  filterOptions: {}
})

export const getFilterOptions = makeAsyncActionCreatorSimp(
  FILTER_OPTIONS_GET, (filterName: FilterableObjectName) => async (/* dispatch: Dispatch, getState: () => State */) => {
    // let fetchFieldFilters: IFilter<FilterBarFilterItem>[] = []
    const { customFields, filters: simpleFilters } = filtersConfig[filterName]

    const dataTypes = simpleFilters.filter(({ type }) => type === FilterType.baseObject)
    let vocabularyFields = simpleFilters.filter(({ type }) => type === FilterType.vocabulary)
    // const fetchFields = simpleFilters.filter(({ type }) => type === FilterType.fetch)

    if (customFields) {
      vocabularyFields = [
        ...vocabularyFields,
        ...getCustomFieldFilter(filterName)
      ]
    }

    let baseObjectsFilterPromise: Promise<IFilter<FilterBarFilterItem>[]> = Promise.resolve([])
    let vocabulariesFilterPromise: Promise<IFilter<FilterBarFilterItem>[]> = Promise.resolve([])

    if (dataTypes?.length) {
      const dataTypesQuery = dataTypes.reduce((query, { name, labelField, keyField }) => query + createSingleFilterQuery(name, labelField, keyField), '')

      baseObjectsFilterPromise = Services.graphQL.fetch<{[key: string]: {Name: string, UID: string}[]}>({
        query: `{${dataTypesQuery}}`
      }).then(dataTypesResp => {
        const baseObjectFilters: IFilter<FilterBarFilterItem>[] = []
        dataTypes.forEach(({ name, label, inputType }) => {
          if (dataTypesResp[name]) {
            baseObjectFilters.push({
              name: label,
              id: name,
              items: dataTypesResp[name].map(defOptionsTransform),
              inputType,
              selectedIds: []
            })
          }
        })
        return baseObjectFilters
      })
    }

    if (vocabularyFields?.length) {
      vocabulariesFilterPromise = getSchemaVocabularies(uniq(vocabularyFields.map(data => data.schemaName).filter(val => !!val)))
        .then(vocabulariesResp => {
          const vocFilters: IFilter<FilterBarFilterItem>[] = []
          vocabularyFields.forEach(({ schemaName, name, label, inputType, fieldType }) => {
            if (vocabulariesResp[schemaName] && vocabulariesResp[schemaName][name]) {
              vocFilters.push({
                name: label,
                id: name,
                items: defaultVocabularyOptionsGenerator(vocabulariesResp[schemaName][name], fieldType),
                inputType,
                selectedIds: []
              })
            }
          })
          return vocFilters
        })
    }


    return {
      resp: {
        [filterName]: await Promise.all([baseObjectsFilterPromise, vocabulariesFilterPromise])
          .then(([baseObjectFilters, vocabularyFields]) => [
            ...baseObjectFilters,
            ...vocabularyFields
          ])
      }
    }
  }
)

const defOptionsTransform = ({ Name, UID }: { Name: string, UID: string }) => ({ id: UID, name: Name })


const transformFilterOptions = (filterOptions: {resp: IFilter<FilterBarFilterItem>[]}, state: State) => {
  const { resp } = filterOptions
  return {
    filterOptions: {
      ...state.filterOptions,
      ...resp
    }
  }
}

export const filterReducers = {
  ...makeReducers(FILTER_OPTIONS_GET, { transform: transformFilterOptions })
}
