import { Dispatch } from 'redux'

import {
  makeActionsSet,
  makeReducers,
  makeAsyncActionCreatorSimp
} from '../common/utils/redux-helpers'

import * as Queries from './queries'
import { Services } from '../Services/Services'
import { getAvatars } from './reducerAvatars'
import { State, Resource, NotificationMethod } from './types'

const RESOURCES_GET = makeActionsSet('RESOURCES_GET')

type ResourcesHelper = Pick<State, 'resources' | 'allResources'>

export const getDefaultResources = () => ({ resources: [], allResources: {} } as ResourcesHelper)

export const getResources = makeAsyncActionCreatorSimp(
  RESOURCES_GET, (variables: { filter?: string } = {}) => async (dispatch: Dispatch, getState: () => State) => {
    const resp = await Services.graphQL.fetch<{ resources: Resource[] }>({
      query: Queries.ResourcesQuery,
      variables
    })

    const savedAvatars = getState().avatars

    dispatch(getAvatars(
      resp.resources
        .map(({ User }) => User && User.UID)
        .filter(UID => UID && !savedAvatars[UID])
    ))

    return { resources: resp.resources }
  }
)

const getResourcePreferredNotificationMethod = (resource: Resource) => {
  switch (resource?.NotificationType as string) {
    case 'push': return NotificationMethod.Push
    case 'sms': return NotificationMethod.SMS
    default: return null
  }
}

const resourcesTransform = ({ resources }: { resources: Resource[] }, state: State) => {
  const newState = resources.reduce<ResourcesHelper>((acc, resource) => {
    const newResource = {
      ...resource,
      Avatar: (resource.User && state.avatars[resource.User.UID])
        ? state.avatars[resource.User.UID]
        : null,
      NotificationType: getResourcePreferredNotificationMethod(resource)
    }
    acc.resources.push(newResource)
    acc.allResources[resource.UID] = { ...newResource }
    return acc
  }, { resources: [], allResources: { ...state.allResources } })

  return newState
}

export const resourcesReducers = {
  ...makeReducers(RESOURCES_GET, { transform: resourcesTransform })
}
