export const CreateBroadcast = `
  mutation createBroadcast($createInput: Newsked_Broadcasts!) {
    schema {
      broadcastId: insertsked_Broadcasts(input: $createInput)
    }
  }
`
