import { inlineLists } from 'common-tags'
import { range } from '../../common/utils/range'

export const CreateBroadcastRecipients = (count: number) => {
  const indexes = range(count)
  return inlineLists(`
    mutation createBroadcastRecipients(${indexes.map(index => `$input${index}: Newsked_BroadcastRecipients!`)}) {
      schema {
      ${indexes.map(index => `recipient${index}:insertsked_BroadcastRecipients(input: $input${index})`)}
      }
    }
  `)
}
