import { inlineLists } from 'common-tags'
import { range } from '../../common/utils/range'

export const UpdateBroadcastRecipients = (count: number) => {
  const indexes = range(count)
  return inlineLists(`
    mutation updateBroadcastRecipients(${indexes.map(index => `$input${index}: Updatesked_BroadcastRecipients!`)}) {
      schema {
      ${indexes.map(index => `recipient${index}:updatesked_BroadcastRecipients(input: $input${index})`)}
      }
    }
  `)
}
