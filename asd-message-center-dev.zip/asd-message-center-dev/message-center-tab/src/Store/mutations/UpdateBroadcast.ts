export const UpdateBroadcast = `
  mutation updateBroadcast($updateInput: Updatesked_Broadcasts!) {
    schema {
      broadcastId: updatesked_Broadcasts(input: $updateInput)
    }
  }
`
