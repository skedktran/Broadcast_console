import {
  makeActionsSet,
  makeReducers,
  makeAsyncActionCreatorSimp
} from '../common/utils/redux-helpers'

import { Services } from '../Services/Services'
import { Avatars, State } from './types'

const AVATARS_GET = makeActionsSet('AVATARS_GET')

export const getDefaultAvatars = () => ({} as Avatars)

export const getAvatars = makeAsyncActionCreatorSimp(
  AVATARS_GET, (ids: string[]) => async () => {
    if (ids.length > 0) {
      const resp = await Services.metadata._apiService.get(
        `files/avatar?user_ids=${[...new Set(ids)]}`
      )
      return { avatars: resp }
    }
    return { avatars: {} }
  }
)

const avatarsTransform = ({ avatars }: { avatars: Avatars }, state: State) => {
  const newResources = state.resources.reduce((acc, resource) => {
    const newResource = {
      ...resource,
      Avatar: (resource.User && avatars[resource.User.UID])
        ? avatars[resource.User.UID]
        : resource.Avatar
    }
    acc.resources.push(newResource)
    acc.allResources[resource.UID] = {
      ...newResource
    }
    return acc
  }, { resources: [], allResources: { ...state.allResources } })
  return {
    ...newResources,
    avatars: { ...state.avatars, ...avatars }
  }
}

export const avatarsReducers = {
  ...makeReducers(AVATARS_GET, { transform: avatarsTransform })
}
