export const ResourcesQuery = `
query getResources ($filter: EQLQueryFilterResources) {
  resources (filter: $filter) {
    edges {
      node {
        UID
        Name
        User {
          UID
        }
        NotificationType
        MobilePhone
        PrimaryRegionId
        Category
      }
    }
  }
}
`
