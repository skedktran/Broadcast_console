
export const SingleBroadcastQuery = `
query getSingleBroadcast($id: ID!, $recipientsFilter: EQLQueryFiltersked_BroadcastRecipients) {
  broadcast: sked_BroadcastsById(UID: $id) {
    UID
    Broadcast: sked_Broadcast
    Date: sked_Date
    NotificationMethod: sked_NotificationMethod
    RecipientType: sked_RecipientType
    Timestamp: sked_Timestamp
    RecipientType: sked_RecipientType
    Sent: sked_Sent
    NotSent: sked_NotSent
    TotalRecipients: sked_TotalRecipients
  }
  broadcastRecipients: sked_BroadcastRecipients(filter: $recipientsFilter) {
    edges {
      node {
        UID
        Date: sked_Date
        Phone: sked_Phone
        Status: sked_Status
        ContactId: sked_ContactId
        ResourceId: sked_ResourceId
        BroadcastId: sked_BroadcastId
        Timestamp: sked_Timestamp
        ErrorInformation: sked_ErrorInformation
        NotificationMethod: sked_NotificationMethod
      }
    }
  }
}
`
