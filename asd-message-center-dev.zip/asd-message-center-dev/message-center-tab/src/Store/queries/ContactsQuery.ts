export const ContactsQuery = `
query getContacts ($filter: EQLQueryFilterContacts) {
  contacts (filter: $filter) {
    edges {
      node {
        UID
        FullName
        MobilePhone
      }
    }
  }
}
`
