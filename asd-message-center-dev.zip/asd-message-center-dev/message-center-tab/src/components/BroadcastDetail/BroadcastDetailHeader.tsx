import React from 'react'
import { StatusIcon } from '@skedulo/sked-ui'

import { BroadcastStatus } from '../../Store'

import { AvatarGroup } from '../AvatarGroup'

interface Props {
  recipient: { avatar: string, name: string, status: BroadcastStatus}
  resendCallback: () => void
}

export const BroadcastDetailHeader: React.FC<Props> = ({ recipient, resendCallback }) => (
  <div className="broadcast-detail-header">
    <AvatarGroup
      users={ recipient ? [recipient] : [] }
      maxAvatarsVisible={ 3 }
    />
    {
      recipient && recipient.status === BroadcastStatus.Error
        ? (
          <div className="broadcast-detail-header__banner broadcast-detail-header__banner--warning">
            <span className="broadcast-detail-header__banner-icon">
              <StatusIcon status="warning" />
            </span>
            Broadcast was not delivered successfully
            <span
              className="broadcast-detail-header__resend"
              onClick={ resendCallback }
            >
              Resend?
            </span>
          </div>
        )
        : (
          <div className="broadcast-detail-header__banner broadcast-detail-header__banner--success">
            <span className="broadcast-detail-header__banner-icon">
              <StatusIcon status="success" />
            </span>
            Broadcast sent successfully
          </div>
        )
      }
  </div>
)
