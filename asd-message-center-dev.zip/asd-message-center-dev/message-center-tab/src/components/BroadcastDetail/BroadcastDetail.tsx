import React, { useState, useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'

import { Recipient as RecipientsListItem } from './RecipientsList'
import { BroadcastSummary } from './BroadcastSummary'
import { BroadcastDetailHeader } from './BroadcastDetailHeader'
import { State, Broadcast, BroadcastStatus, RecipientType } from '../../Store'
import {
  rebroadcastResources,
  rebroadcastContacts,
  getBroadcastById
} from '../../Store/reducerBroadcasts'

import './BroadcastDetail.scss'

interface ListItem extends RecipientsListItem {
  status: BroadcastStatus
  resourceId?: string
  contactId?: string
}

const selectBroadcastRecipients = (state: State, broadcast: Broadcast) => {
  if (!broadcast) return []

  return broadcast.RecipientIds
    .map(id => state.broadcastRecipients[id])
    .filter(recipient => !!recipient)
}

const selectRecipientListItems = (state: State, broadcast: Broadcast, recipientId: string) => {
  const recipient = selectBroadcastRecipients(state, broadcast).find(({ ResourceId }) => ResourceId === recipientId)
  const resource = state.resources.find(({ UID }) => UID === recipientId)

  return [{
    id: recipient.UID,
    name: resource?.Name,
    avatar: resource?.Avatar,
    notificationMethod: recipient?.NotificationMethod,
    phone: resource?.MobilePhone,
    status: recipient.Status,
    resourceId: resource?.UID,
    // contactId: null,
    loading: false
  }]
}

interface Props {
  broadcastId: string
  recipientId: string
}

export const BroadcastDetail: React.FC<Props> = ({ broadcastId, recipientId }) => {
  const broadcast = useSelector((state: State) => state.broadcasts.find(({ UID }) => UID === broadcastId))
  const state = useSelector((state: State) => state)
  const [recipientItems, setRecipientItems] = useState([] as ListItem[])

  useEffect(() => {
    setRecipientItems(selectRecipientListItems(state, broadcast, recipientId))
  }, [broadcast, state.resources, recipientId])

  const dispatch = useDispatch()

  if (!broadcast) return <div>No broadcast</div>

  const setRecipientsLoading = (recipientIds: string[], loading: boolean) => {
    setRecipientItems(recipientItems.map(item => (
      recipientIds.includes(item.id) ? { ...item, loading } : item
    )))
  }

  const resend = (recipientIds: string[]) => {
    console.error(recipientIds)

    setRecipientsLoading(recipientIds, true)
    if (broadcast.RecipientType === RecipientType.Resource) {
      dispatch(rebroadcastResources(
        broadcast.UID,
        recipientIds,
        recipientIds.reduce((acc, id) => ({
          ...acc,
          [id]: recipientItems.find(item => item.id === id)?.notificationMethod
        }), {}),
        () => dispatch(getBroadcastById(broadcast.UID))
      ))
    } else if (broadcast.RecipientType === RecipientType.Contact) {
      dispatch(rebroadcastContacts(
        broadcast.UID,
        recipientIds,
        () => dispatch(getBroadcastById(broadcast.UID))
      ))
    }
  }

  return (
    <div className="broadcast-detail">
      <div className="broadcast-detail__header">
        <BroadcastDetailHeader
          recipient={ recipientItems[0] }
          resendCallback={ () => resend([recipientItems[0].id]) }
        />
      </div>
      <div className="broadcast-detail__body">
        <div className="broadcast-detail__summary">
          <BroadcastSummary content={ broadcast.Broadcast } date={ broadcast.Date } />
        </div>
      </div>
    </div>
  )
}
