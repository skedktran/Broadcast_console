import React, { ReactElement } from 'react'
import { AvatarDetail, Icon, Button, PopOut, Menu, MenuItem } from '@skedulo/sked-ui'

import { NotificationMethod, RecipientType } from '../../Store'

export interface Recipient {
  id: string
  avatar: string
  name: string
  notificationMethod: NotificationMethod
  phone: string
  loading: boolean
}

interface NotificationMethodSwitchProps {
  notificationMethod: NotificationMethod
  onMethodChange: (newMethod: NotificationMethod) => void
}

const NotificationMethodSwitch: React.FC<NotificationMethodSwitchProps> = props => (
  <PopOut
    placement="bottom"
    closeOnFirstClick
    trigger={
      () => (
        <div className="recipients-list__item-method">
          { props.notificationMethod }
          <Icon name="edit" className="recipients-list__item-method-icon" size={ 14 } />
        </div>
      )
    }
  >
    { () => (
      <Menu>
        <MenuItem onClick={ () => props.onMethodChange(NotificationMethod.SMS) }>SMS</MenuItem>
        <MenuItem onClick={ () => props.onMethodChange(NotificationMethod.Push) }>Push</MenuItem>
      </Menu>
    ) }
  </PopOut>
)

interface RecipientsListItemProps {
  recipientType: RecipientType
  recipient: Recipient
  recipientActionLabel?: string
  recipientActionCallback?: (recipientId: string) => void
  loading: boolean
  onNotificationMethodChange?: (newMethod: NotificationMethod) => void
}

export const RecipientListItem: React.FC<RecipientsListItemProps> = props => (
  <li className="recipients-list__item">
    <div className="recipients-list__item-avatar">
      <AvatarDetail
        name={ props.recipient.name }
        imageUrl={ props.recipient.avatar }
        size="medium"
      />
    </div>
    {
      props.recipientType === RecipientType.Resource &&
      !!props.onNotificationMethodChange &&
      <NotificationMethodSwitch
        notificationMethod={ props.recipient.notificationMethod }
        onMethodChange={ props.onNotificationMethodChange }
      />
    }
    <div className="recipients-list__item-phone">
      {
        props.recipient.phone ||
        <span className="recipients-list__item-phone-placeholder">none</span>
      }
    </div>
    {
      !!props.recipientActionCallback &&
      <div className="recipients-list__item-action">
        <Button
          className="recipients-list__item-action-button"
          onClick={ () => props.recipientActionCallback(props.recipient.id) }
          buttonType="transparent"
          loading={ props.loading }
        >
          { props.recipientActionLabel }
        </Button>
      </div>
    }
  </li>
)

interface RecipientsListProps {
  expanded: boolean
  onExpandToggle: () => void
  headerIcon: ReactElement
  headerLabel: string
  itemActionLabel?: string
  itemActionCallback?: (recipientId: string) => void
  batchActionLabel: string
  batchActionCallback: (recipientIds: string[]) => void
  recipients: Recipient[]
  type: RecipientType
  onItemNotificationMethodChange?: (recipientId: string, newMethod: NotificationMethod) => void
}

export const RecipientsList: React.FC<RecipientsListProps> = props => {
  return (
    <div className="recipients-list">
      <div className="recipients-list__header">
        <div className="recipients-list__header-summary">
          <span className="recipients-list__header-summary-icon">{ props.headerIcon }</span>
          { props.headerLabel } ({ props.recipients.length })
        </div>
        <div className="recipients-list__header-action">
          <span
            className="recipients-list__header-action-button"
            onClick={ () => props.batchActionCallback(props.recipients.map(recipient => recipient.id)) }
          >
            { props.batchActionLabel }
          </span>
          <span className="recipients-list__header-action-icon">
            <Icon
              name="chevronDown"
              size={ 18 }
              onClick={ props.onExpandToggle }
            />
          </span>
        </div>
      </div>
      {
        props.expanded &&
        <div className="recipients-list__content">
          <ul className="recipients-list__list">
            {
              props.recipients.map(recipient => (
                <RecipientListItem
                  key={ recipient.id }
                  recipientType={ props.type }
                  recipient={ recipient }
                  recipientActionCallback={ props.itemActionCallback }
                  recipientActionLabel={ props.itemActionLabel }
                  loading={ recipient.loading }
                  onNotificationMethodChange={
                    props.onItemNotificationMethodChange
                      ? newMethod => props.onItemNotificationMethodChange(recipient.id, newMethod)
                      : null
                  }
                />
              ))
            }
          </ul>
        </div>
      }
    </div>
  )
}
