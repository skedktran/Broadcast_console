import React from 'react'

interface Props {
  date: string
  content: string
}

export const BroadcastSummary: React.FC<Props> = ({ date, content }) => (
  <div className="broadcast-summary">
    <div className="broadcast-summary__row">
      <span className="broadcast-summary__label">Date:</span>
      <span>{ date }</span>
    </div>
    <div className="broadcast-summary__row">
      <span className="broadcast-summary__label">Broadcast:</span>
      <p>{ content }</p>
    </div>
  </div>
)
