import React from 'react'
import { FormInputElement } from '@skedulo/sked-ui'
import { Icon } from 'skedulo-ui'
import classnames from 'classnames'

import './SearchField.scss'

type Props = {
  fullWidth?: boolean
  onChange: (event: string) => void
  value?: string
}

const SearchField: React.FC<Props> = ({ fullWidth = false, onChange, value }) => {
  return (
    <div className={ classnames('search-field', {
      'full-width': fullWidth
    }) }
    >
      <Icon name="search" size={ 18 } />
      <FormInputElement
        type="text"
        placeholder="Search..."
        onChange={ event => onChange(event.target.value.toLowerCase()) }
        className="search-field__input"
        value={ value }
      />
    </div>
  )
}

export default SearchField
