import React from 'react'

import './MessageInput.scss'

interface MessageInputProps {
  value: string
  maxLength: number
  onChange: (message: string) => void
  placeholder: string
}

const MessageInput: React.FC<MessageInputProps> = ({ value, maxLength, onChange, placeholder }) => (
  <div className="message-input">
    <div className="message-input__header">
      {/* unable to use <label> tag here because of eslint error */}
      <span>Type Broadcast</span>
      <span>{ value ? value.length : 0 } / { maxLength }</span>
    </div>
    <textarea
      className="message-input__message"
      id="message"
      name="message"
      value={ value }
      maxLength={ maxLength }
      required
      onChange={ e => onChange(e.target.value) }
      placeholder={ placeholder }
    />
  </div>
)

export default MessageInput
