import React from 'react'
import { useSelector } from 'react-redux'
import { AvatarDetail } from '@skedulo/sked-ui'

import { State } from '../../Store'
import { AvatarGroup } from '../AvatarGroup'
import { context } from '../../Services/Services'

import './MessengerHeader.scss'

export const MessengerHeader: React.FC = () => {
  let content = null

  // ADAM: 000579c4-3476-4c86-86ee-8f4619797544
  // BARTEK: 00055ca8-3452-4ed7-b91d-9fbc2209ac5a
  // @ts-ignore
  const userId = context.resourceUID
  const resource = useSelector(({ allResources }: State) => allResources[userId])

  const { Name, Avatar, NotificationType, Category } = resource || {}

  content = (<SingleHeader
    name={ Name }
    description={ Category }
    preferredMethod={ NotificationType }
    avatarUrl={ Avatar }
  />)
  return (
    <div className="messenger-header">
      {content}
    </div>
  )
}

export const ContactsMessengerHeader: React.FC = () => {
  let content = null
  const contacts = useSelector(({ selectedContacts, allContacts }: State) => selectedContacts.map(UID => allContacts[UID]))

  if (contacts.length === 1) {
    const { FullName } = contacts[0]
    content = (<SingleHeader
      name={ FullName }
    />)
  }
  if (contacts.length > 1) {
    const users = contacts.map(({ FullName }) => ({ name: FullName, avatar: null }))
    content = (
      <>
        <AvatarGroup users={ users } maxAvatarsVisible={ 4 } />
      </>
    )
  }
  return (
    <div className="messenger-header">
      {content}
    </div>
  )
}

interface MessengerHeaderProps {
  name: string
  description?: string
  preferredMethod?: string
  avatarUrl?: string
}

const SingleHeader: React.FC<MessengerHeaderProps> = ({
  name,
  description,
  preferredMethod,
  avatarUrl
}) => (
  <>
    <AvatarDetail
      name={ name }
      imageUrl={ avatarUrl }
      subtitle={ <span>{ description || '' }</span> }
      size="medium"
    />
    {preferredMethod &&
    <div className="messenger-header__method">
      Preferred method: <span>{ preferredMethod }</span>
    </div>}
  </>
)

export default MessengerHeader
