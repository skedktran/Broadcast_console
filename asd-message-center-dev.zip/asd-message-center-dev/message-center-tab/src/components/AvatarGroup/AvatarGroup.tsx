import React, { useState } from 'react'

import { Avatar } from '@skedulo/sked-ui'

import './AvatarGroup.scss'

type User = {
  avatar: string
  name: string
}

type AvatarGroupProps = {
  users: User[]
  maxAvatarsVisible?: number
}

const AvatarWrapper: React.FC<User> = ({ avatar, name }) => (
  <div className="avatar-group__avatar-wrapper">
    <Avatar name={ name } imageUrl={ avatar } />
  </div>
)

export const AvatarGroup: React.FC<AvatarGroupProps> = ({ users, maxAvatarsVisible = 4 }) => {
  const [truncatedResourcesVisible, toggleTruncatedResourcesVisibility] = useState(false)

  return (
    <span className="avatar-group">
      {
      users.map(({ avatar, name }, i) => {
        if (users.length <= maxAvatarsVisible || i <= maxAvatarsVisible - 2) {
          return <AvatarWrapper avatar={ avatar } name={ name } key={ i } />
        }

        if (i === maxAvatarsVisible - 1) {
          const truncatedResources = users.slice(maxAvatarsVisible - 1)
          return (
            <div className="avatar-group__truncated-resources-wrapper" key={ i }>
              <div
                className="avatar-group__truncated-resources-number"
                onClick={ e => {
                  e.stopPropagation()
                  toggleTruncatedResourcesVisibility(!truncatedResourcesVisible)
                } }
              >
                  +{ users.length - (maxAvatarsVisible - 1) }
              </div>
              { truncatedResourcesVisible &&
              <div className="avatar-group__truncated-resources-list">
                <ul>
                  { truncatedResources.map(({ avatar: resAvatar, name: resName }, i) => (
                    <li key={ i }>
                      <AvatarWrapper avatar={ resAvatar } name={ resName } />
                      <span>{ resName }</span>
                    </li>
                  )) }
                </ul>
              </div>}
            </div>
          )
        }

        return ''
      })
    }

      { users.length === 1 && <span className="avatar-group__name">{ users[0].name }</span> }

    </span>
  )
}
