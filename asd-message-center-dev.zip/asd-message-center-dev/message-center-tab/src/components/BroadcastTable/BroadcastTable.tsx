import React, { useState, useEffect } from 'react'
import { Pagination } from '@skedulo/sked-ui'

import { DynamicTable, TableConfig } from 'skedulo-ui'
import { DateCell, StatusCell, RecipientsCell } from './cells'
import { Broadcast, NotificationMethod, RecipientType } from '../../Store'

import './BroadcastTable.scss'

type Props = {
  broadcasts: Broadcast[]
  textFilter: string
  recipientType: RecipientType
  onSelect: (broadcast: Broadcast) => void
  className?: string
  paginationClassName?: string
}

const config: TableConfig<Broadcast> = {
  columns: [
    {
      key: 'Timestamp',
      name: 'Date',
      cellRenderer: (_, row) => <DateCell timestamp={ row.Timestamp } />,
      width: 160
    },
    {
      key: 'Broadcast',
      name: 'Broadcast'
    },
    {
      key: 'RecipientIds',
      name: 'Recipients',
      cellRenderer: (_, row) => <RecipientsCell recipientIds={ row.RecipientIds } />,
      width: 250
    },
    {
      key: 'Sent',
      name: 'Status',
      emptyPlaceholderText: '-',
      cellRenderer: (_, row) => <StatusCell sent={ row.Sent } notSent={ row.NotSent } />,
      width: 160
    },
    {
      key: 'NotificationMethod',
      name: 'Method',
      cellRenderer: method => method === NotificationMethod.Preferred ? 'Preferred' : method,
      width: 160
    }
  ]
}

const BroadcastTable: React.FC<Props> = ({ broadcasts, textFilter, onSelect, className, paginationClassName }) => {
  const itemsPerPage = 25
  const [currentPage, setCurrentPage] = useState(1)
  const [totalItems, setTotalItems] = useState(broadcasts.length)
  const [currentBroadcasts, setCurrentBroadcasts] = useState([])

  useEffect(() => {
    setCurrentPage(1)
  }, [textFilter])

  useEffect(() => {
    const start = (currentPage - 1) * itemsPerPage
    const end = currentPage * itemsPerPage
    const filteredBroadcasts = textFilter
      ? broadcasts.filter(broadcast => broadcast.Broadcast.toLowerCase().includes(textFilter))
      : broadcasts

    setTotalItems(filteredBroadcasts.length)
    setCurrentBroadcasts(filteredBroadcasts.slice(start, end))
  }, [broadcasts, currentPage, textFilter])

  return (
    <>
      <div className={ className }>
        <DynamicTable
          onRowClick={ onSelect }
          selection={ new Set() }
          data={ currentBroadcasts }
          config={ config }
          className="broadcast-table"
        />
      </div>
      <div className={ paginationClassName }>
        { !!totalItems && <Pagination
          itemsTotal={ totalItems }
          itemsPerPage={ itemsPerPage }
          currentPage={ currentPage }
          onPageChange={ setCurrentPage }
          currentPageSiblings={ 1 }
        /> }
      </div>
    </>
  )
}

export default BroadcastTable
