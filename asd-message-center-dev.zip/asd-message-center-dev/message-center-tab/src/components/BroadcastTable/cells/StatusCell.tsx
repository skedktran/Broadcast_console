import React from 'react'
import { StatusIcon } from '@skedulo/sked-ui'

import './StatusCell.scss'

type Props = {
  sent: number
  notSent: number
}

const StatusCell: React.FC<Props> = ({ sent, notSent }) => {
  const completed = notSent === 0
  const total = sent + notSent
  return (
    <div className="status-cell">
      <StatusIcon status={ completed ? 'success' : 'warning' } />
      { !completed && <span className="status-cell__not-sent">{ sent }/{ total }</span>}
    </div>
  )
}

export default StatusCell
