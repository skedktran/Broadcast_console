import React, { useState, useEffect } from 'react'
import { useSelector } from 'react-redux'
import { State, BroadcastRecipient, Resource, Contact } from '../../../Store'
import { AvatarGroup } from '../../AvatarGroup'

type Props = {
  recipientIds: string[]
}

const RecipientsCell: React.FC<Props> = ({ recipientIds }) => {
  const [users, setUsers] = useState([])

  const broadcastRecipients = useSelector<State, { [id: string]: BroadcastRecipient }>(state => state.broadcastRecipients)
  const resources = useSelector<State, Resource[]>(state => state.resources)
  const contacts = useSelector<State, Contact[]>(state => state.contacts)

  const toUsers = (recipientId: string) => {
    const recipient = broadcastRecipients[recipientId]
    const resource = recipient.ResourceId ? resources.find(resource => resource.UID === recipient.ResourceId) : undefined
    const contact = recipient.ContactId ? contacts.find(contact => contact.UID === recipient.ContactId) : undefined
    return {
      avatar: resource?.Avatar || undefined,
      name: resource?.Name || contact?.FullName || ''
    }
  }

  useEffect(() => {
    setUsers(recipientIds.map(toUsers))
  }, [recipientIds, broadcastRecipients, resources])

  return (
    <>
      <div>
        <AvatarGroup users={ users } maxAvatarsVisible={ 2 } />
      </div>
    </>
  )
}

export default RecipientsCell
