import React from 'react'
import { format } from 'date-fns'

import './DateCell.scss'

type Props = {
  timestamp: string
};

const DateCell: React.FC<Props> = ({ timestamp }) => {
  const sendDate = new Date(parseInt(timestamp, 10))
  const date = sendDate ? format(sendDate, 'd MMM y') : ''
  const time = sendDate ? format(sendDate, 'H:mm') : ''
  return (
    <div className="date-cell">
      <div className="date-cell__date">{date}</div>
      <div className="date-cell__time">{time}</div>
    </div>
  )
}

export default DateCell
