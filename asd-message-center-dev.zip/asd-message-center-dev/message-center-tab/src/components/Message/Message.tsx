import React from 'react'
import { StatusIcon } from '@skedulo/sked-ui'

import './Message.scss'

interface MessageProps {
  message: string
  date: Date
  status: string
  onResend: () => void
}

const Message: React.FC<MessageProps> = ({
  message,
  date,
  status,
  onResend
}) => (
  // disabled eslint because of weird autformating and fake errors
  /* eslint-disable */
  <div className="message">
    <span className="message__date">
      { `${date.getDate()}.${date.getMonth()}.${date.getFullYear()}` }
    </span>
    <div className="message__content">{ message }</div>
    <div className="message__status-container">
      {
        status === 'sent'
          ? (
            <div className="message__status message__status--sent">
              <StatusIcon status="success" />
                Sent
            </div>
          )
          : (
            <div className="message__status message__status--error">
              <StatusIcon status="error" />
                Error sending message.
              {/* TODO: add resend action */}
              <span className="message__resend" role="button" onClick={ onResend } tabIndex={ 0 }>
                Resend?
              </span>
            </div>
          )
      }
    </div>
  </div>
)

export default Message
