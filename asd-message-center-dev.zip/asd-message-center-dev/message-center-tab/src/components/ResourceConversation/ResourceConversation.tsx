import React from 'react'

import Message from '../Message'
import { Broadcast } from '../../Store'

import './ResourceConversation.scss'

interface ResourceConversationProps {
  broadcasts: Broadcast[]
  onResend: () => void
}

const ResourceConversation: React.FC<ResourceConversationProps> = ({ broadcasts, onResend }) => (
  <div className="resource-conversation">
    {
      broadcasts.length > 0
        ? broadcasts.map(broadcast => (
          <Message
            message={ broadcast.Broadcast }
            date={ new Date(broadcast.Date) }
            status="sent"
            key={ broadcast.UID }
            onResend={ onResend }
          />
        ))
        : <div className="sent-messages__no-messages">No previous messages</div>
    }
  </div>
)

export default ResourceConversation
