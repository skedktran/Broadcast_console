/*
import React from 'react'

import { DynamicTable, TableConfig, TableTotalConfig, Pagination } from 'skedulo-ui'

import './TimesheetsTable.scss'

const itemsPerPage = 25

interface Props<Item> {
  items: Item[]
  onDelete: (timesheetId: string) => void
  onSelect?: (selectedTimesheetsUIDs: Set<string>) => void
  expandedRowUID: string
  setExpandedUID: typeof setExpandedUID
  onSearch: (item: Item, searchPhrase: string) => boolean
}

interface State<Item> {
  filteredItems: Item[]
  currentPage: number
  selectedTimesheetsUIDs: Set<string>
}

class Table<Item> extends React.Component<Props<Item>, State<Item>> {
  constructor(props: Props<Item>) {
    super(props)

    this.state = {
      filteredItems: this.props.items,
      currentPage: 1,
      selectedTimesheetsUIDs: new Set()
    }
  }

  onSelect = (_: keyof Item, selectedTimesheetsUIDs: Set<string>) => {
    this.setState({
      selectedTimesheetsUIDs
    })
    if (this.props.onSelect) {
      this.props.onSelect(selectedTimesheetsUIDs)
    }
  }

  componentDidUpdate(prevProps: Props<Item>) {
    if (this.props.items !== prevProps.items) {
      this.setState({
        filteredItems: this.props.items,
        currentPage: 1
      })
    }
  }

  onSearch = (searchPhrase: string) => {
    this.setState({
      filteredItems: this.filterBySearchPhrase(this.props.items, searchPhrase),
      currentPage: 1
    })
  }

  filterBySearchPhrase(items: Item[], searchPhrase: string) {
    return items.filter(item => this.props.onSearch(item, searchPhrase))
  }

  onSearchClear = () => {
    this.setState({
      filteredItems: this.props.items,
      currentPage: 1
    })
  }

  onPageChange = (page: number) => {
    this.setState({
      currentPage: page,
      selectedTimesheetsUIDs: new Set()
    })
    if (this.props.onSelect) {
      this.props.onSelect(new Set())
    }
  }

  getDisplayedItems() {
    return this.state.filteredItems.slice(
      (this.state.currentPage - 1) * itemsPerPage,
      this.state.currentPage * itemsPerPage
    )
  }

  renderNoItemsPlaceholder() {
    return (
      <div className="sk-flex sk-items-center sk-justify-center sk-w-full">
        <span className="sk-text-xs sk-mt-12 sk-mb-8">No items available</span>
      </div>
    )
  }

  render() {
    if (this.state.filteredItems) {
      const displayedItems = this.getDisplayedItems()
      return (
        <div className="table">
          <section className="table__section table__dynamic-table">
            <DynamicTable
              data={ displayedItems }
              config={ this.state.tableConfig }
              selection={ this.state.selectedTimesheetsUIDs }
              totalConfig={ this.state.totalConfig }
              expandedRows={ new Set([this.props.expandedRowUID]) }
              onRowExpand={ this.props.setExpandedUID }
            />
            { displayedItems.length === 0 && this.renderNoItemsPlaceholder() }
          </section>
          {
            displayedItems.length > 0 &&
            <section className="table__section table__pagination">
              <Pagination
                itemsTotal={ this.state.filteredItems.length }
                itemsPerPage={ itemsPerPage }
                currentPage={ this.state.currentPage }
                onPageChange={ this.onPageChange }
              />
            </section>
          }
        </div>
      )
    }

    return (<div>Loading...</div>)
  }
}
*/
