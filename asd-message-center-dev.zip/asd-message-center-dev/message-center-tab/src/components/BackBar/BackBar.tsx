import * as React from 'react'
import { Button } from '@skedulo/sked-ui'
import { useHistory } from 'react-router-dom'


export const BackBar: React.FC<{route: string}> = ({ route, children }) => {
  const history = useHistory()
  return (
    <div className="backbar__container">
      <Button
        buttonType="transparent"
        compact
        disabled={ false }
        loading={ false }
        icon="chevronLeft"
        onClick={ () => history.push(route) }
      >
        {children || 'Back To Broadcasts'}
      </Button>
    </div>
  )
}
