import React from 'react'
import { DynamicModal, Button } from '@skedulo/sked-ui'

import { BroadcastDetail } from '../../components/BroadcastDetail'

import './BroadcastDetailModal.scss'

const headerModal = () => (
  <div className="broadcast-detail__heading">
    <h1>Broadcast Details</h1>
  </div>
)

const footerModal = (onClose: () => void) => (
  <div className="broadcast-detail__footer">
    <Button
      buttonType="primary"
      onClick={ onClose }
    >OK
    </Button>
  </div>
)

type Props = {
  broadcastId: string
  recipientId: string
  onClose: () => void
}

const BroadcastDetailsModal: React.FC<Props> = ({ onClose, broadcastId, recipientId }) => {
  return (
    <DynamicModal
      className="broadcast-details-modal"
      header={ headerModal() }
      footer={ footerModal(onClose) }
    >
      <BroadcastDetail broadcastId={ broadcastId } recipientId={ recipientId } />
    </DynamicModal>

  )
}

export default BroadcastDetailsModal
