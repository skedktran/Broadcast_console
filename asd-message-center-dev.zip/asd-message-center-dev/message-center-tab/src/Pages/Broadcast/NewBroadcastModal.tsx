import React, { useState } from 'react'
import { DynamicModal, Button } from '@skedulo/sked-ui'
import { useDispatch } from 'react-redux'

import { NotificationMethod } from '../../Store'
import { broadcastResources } from '../../Store/reducerBroadcasts'
import MessageInput from '../../components/MessageInput'
import MessengerHeader from '../../components/MessengerHeader'

import './NewBroadcastModal.scss'

const headerModal = () => (
  <div className="broadcast-detail__heading">
    <h1>Send Broadcast</h1>
  </div>
)

const footerModal = (onClose: () => void) => (
  <div className="broadcast-detail__footer">
    <Button
      buttonType="primary"
      onClick={ onClose }
    >Close
    </Button>
  </div>
)

type Props = {
  recipientId: string
  onClose: (fetchNew?: boolean) => () => void
}

const NewBroadcastModal: React.FC<Props> = ({ onClose, recipientId }) => {
  const dispatch = useDispatch()

  const [newMessage, setNewMessage] = useState('')
  const [loader, setLoader] = useState(undefined)

  const selectedResources = [recipientId]

  const onSuccess = onClose(true)

  const sendBroadcast = (method: NotificationMethod) => () => {
    setLoader(method)
    dispatch(broadcastResources({
      message: newMessage,
      resourceIds: selectedResources,
      notificationMethod: method
    }, onSuccess))
  }

  return (
    <DynamicModal
      className="broadcast-details-modal"
      header={ headerModal() }
      footer={ footerModal(onClose(false)) }
    >

      <div className="messenger">
        <MessengerHeader />
        <div className="messenger__messages">
          <div className="messenger__new-message">
            <MessageInput
              value={ newMessage }
              maxLength={ 500 }
              onChange={ setNewMessage }
              placeholder="Type here"
            />
            <div className="messenger__buttons-wrapper">
              <div className="messenger__send-methods">
                <Button
                  buttonType="secondary"
                  disabled={ !newMessage.length || (loader && loader !== NotificationMethod.SMS) }
                  onClick={ sendBroadcast(NotificationMethod.SMS) }
                  loading={ loader === NotificationMethod.SMS }
                >
                  Send SMS
                </Button>
                <Button
                  disabled={ !newMessage.length || (loader && loader !== NotificationMethod.Push) }
                  buttonType="secondary"
                  onClick={ sendBroadcast(NotificationMethod.Push) }
                  loading={ loader === NotificationMethod.Push }
                >
                  Send in app
                </Button>
              </div>
              <Button
                disabled={ !newMessage.length || (loader && loader !== NotificationMethod.Preferred) }
                buttonType="primary"
                onClick={ sendBroadcast(NotificationMethod.Preferred) }
                loading={ loader === NotificationMethod.Preferred }
              >
                Send via Preferred Method
              </Button>
            </div>
          </div>
        </div>
      </div>

    </DynamicModal>

  )
}

export default NewBroadcastModal
