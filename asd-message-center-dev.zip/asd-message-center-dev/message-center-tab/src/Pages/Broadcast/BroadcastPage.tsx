import * as React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Button, CalendarControls, RangeType } from '@skedulo/sked-ui'
import { startOfMonth, startOfDay, addDays, getDaysInMonth, endOfDay } from 'date-fns'

import SearchField from '../../components/SearchField'
import BroadcastTable from '../../components/BroadcastTable'
import BroadcastDetailsModal from './BroadcastDetailModal'
import NewBroadcastModal from './NewBroadcastModal'

import { State, RecipientType } from '../../Store'
import { getBroadcasts } from '../../Store/reducerBroadcasts'
// import { useFilters } from '../../Store/filters/useFilters'
import { getResources } from '../../Store/reducerResources'
import { context } from '../../Services/Services'

import './BroadcastPage.scss'

interface Props {
  recipientType: RecipientType
}

type RangeFilterState = {
  selected: Date
  range: RangeType
}

const getEndDate = (date: Date, range: RangeType) => {
  switch (range) {
    case 'month': return addDays(date, getDaysInMonth(date))
    case '2-weeks': return addDays(date, 14)
    case 'week': return addDays(date, 7)
    case '3-days': return addDays(date, 3)
    case 'day': return endOfDay(date)
  }

  return endOfDay(date)
}

// @ts-ignore
const resourceId = context.resourceUID

export const BroadcastPage: React.FC<Props> = ({ recipientType }) => {
  const dispatch = useDispatch()

  const [textFilter, setTextFilter] = React.useState('')
  const [rangeFilter, setRangeFilter] = React.useState<RangeFilterState>({
    selected: startOfMonth(new Date()),
    range: 'month'
  })

  const [broadcastDetailsId, setBroadcastDetailsId] = React.useState(null)
  const [showNewBroadcastModal, setShowNewBroadcastModal] = React.useState(false)

  // const { filterString } = useFilters('Resources')

  React.useEffect(() => {
    dispatch(getResources({ filter: `UID == "${resourceId}"` }))
    dispatch(getBroadcasts(RecipientType.Resource, rangeFilter.selected, getEndDate(rangeFilter.selected, rangeFilter.range), resourceId))
  }, [rangeFilter])

  const broadcasts = useSelector((state: State) => state.broadcasts)

  return (
    <div className="broadcast-resource">

      {
        broadcastDetailsId && (
          <BroadcastDetailsModal
            onClose={ () => setBroadcastDetailsId(null) }
            broadcastId={ broadcastDetailsId }
            recipientId={ resourceId }
          />
        )
      }

      {
        showNewBroadcastModal && <NewBroadcastModal
          recipientId={ resourceId }
          onClose={ (fetchNew?: boolean) => () => {
            if (fetchNew) {
              dispatch(getBroadcasts(RecipientType.Resource, rangeFilter.selected, getEndDate(rangeFilter.selected, rangeFilter.range), resourceId))
            }
            setShowNewBroadcastModal(false)
          } }
        />
      }

      <div className="broadcast-resource__header">
        <div className="broadcast-resource__filters" />
        <Button
          buttonType="primary"
          compact={ false }
          disabled={ false }
          onClick={ () => setShowNewBroadcastModal(true) }
        >
          Send Broadcast
        </Button>
      </div>
      <div className="broadcast-resource__table-controls">
        <div className="broadcast-resource__calendar-controls">
          <CalendarControls
            selected={ rangeFilter.selected }
            selectedRange={ rangeFilter.range }
            onTodayClick={ () => setRangeFilter({ ...rangeFilter, selected: startOfDay(new Date()) }) }
            onDateSelect={ selected => setRangeFilter({ ...rangeFilter, selected }) }
            onRangeChange={ range => setRangeFilter({ ...rangeFilter, range }) }
            rangeOptions={ ['day', '3-days', 'week', 'month'] }
          />
        </div>
        <SearchField onChange={ setTextFilter } />
      </div>
      <BroadcastTable
        onSelect={ ({ UID }) => setBroadcastDetailsId(UID) }
        broadcasts={ broadcasts }
        textFilter={ textFilter }
        recipientType={ recipientType }
        className="broadcast-resource__table"
        paginationClassName="broadcast-resource__pagination"
      />
    </div>
  )
}
